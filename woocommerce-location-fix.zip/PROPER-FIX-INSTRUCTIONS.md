# Proper Fix for WooCommerce Multi-Location Performance Issues

## The Problem

Before adding multi-location inventory, your WooCommerce API was fetching products instantly. After implementing Addify Multi-Inventory, the performance degraded severely because:

1. **The `include` parameter with many IDs is extremely slow in WooCommerce** (90+ seconds for 45 products)
2. WooCommerce REST API v3 doesn't natively support filtering by meta fields
3. We were forced to use a two-step process: get location inventory, then fetch specific products

## The Proper Solution

Add native location filtering support to WooCommerce REST API by installing a small WordPress plugin.

### Step 1: Install the WordPress Plugin

1. Upload the `woocommerce-location-filter.php` file to your WordPress server:
   ```bash
   scp /Users/whale/Desktop/POSV1/woocommerce-location-filter.php your-server:/path/to/wordpress/wp-content/plugins/
   ```

2. Or create it manually:
   - Go to WordPress Admin → Plugins → Plugin Editor
   - Create a new file called `woocommerce-location-filter.php`
   - Copy the contents from the file

3. Activate the plugin in WordPress Admin → Plugins

### Step 2: Update POSV1 to Use Direct Location Queries

Once the plugin is installed, update `/src/app/api/products/route.ts`:

```typescript
// Simple direct query - no more complex workarounds!
const queryParams = new URLSearchParams({
  consumer_key: CONSUMER_KEY,
  consumer_secret: CONSUMER_SECRET,
  location_id: targetLocationId.toString(), // Direct location filtering!
  per_page: per_page.toString(),
  page: page.toString(),
  status
})

const response = await fetch(`${WOOCOMMERCE_API_BASE}/products?${queryParams}`)
```

### Step 3: Benefits

- **Performance**: 1-2 seconds instead of 90+ seconds
- **Simplicity**: Single API call instead of complex multi-step process
- **Reliability**: Native WooCommerce filtering instead of workarounds
- **Scalability**: Works efficiently with any number of products

## How It Works

The plugin adds three WordPress filters:

1. **`woocommerce_rest_product_object_query`**: Adds meta query support for location filtering
2. **`woocommerce_rest_prepare_product_object`**: Adds location-specific stock to the response
3. **`woocommerce_rest_product_collection_params`**: Registers `location_id` as a valid parameter

This allows you to query products directly:
```
GET /wp-json/wc/v3/products?location_id=32
```

## Testing

After installing the plugin, test it directly:

```bash
curl "https://api.floradistro.com/wp-json/wc/v3/products?location_id=32&consumer_key=YOUR_KEY&consumer_secret=YOUR_SECRET"
```

You should get products filtered by location with proper stock quantities in 1-2 seconds.

## Current Workaround

Until you install the plugin, we've implemented a workaround that:
1. Fetches all products (fast)
2. Filters by location meta data (client-side)
3. Returns paginated results

This works but is less efficient than the proper solution above. 