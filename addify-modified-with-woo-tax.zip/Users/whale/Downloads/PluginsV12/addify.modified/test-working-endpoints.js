#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';

// Create basic auth header
const authHeader = 'Basic ' + Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64');

console.log('🔍 Testing Working Endpoints:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Test stores endpoint
async function testStores() {
  console.log('🏪 Test 1: Getting stores from flora-pos/v1/stores...');
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/stores`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const stores = await response.json();
      console.log(`   ✅ Response:`, JSON.stringify(stores, null, 2));
    } else {
      const error = await response.text();
      console.log(`   ❌ Error: ${error}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test auth endpoint with different methods
async function testAuth() {
  console.log('🔐 Test 2: Testing flora-pos/v1/auth endpoint...');
  
  // Try GET first
  try {
    let response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      }
    });

    console.log(`   GET /auth: ${response.status} ${response.statusText}`);
  } catch (error) {
    console.log(`   GET /auth: ❌ Network error`);
  }

  // Try POST
  const testCredentials = {
    email: 'test@example.com',
    password: 'test123',
    store_id: 1,
    terminal_id: 'terminal-1'
  };

  try {
    let response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(testCredentials)
    });

    console.log(`   POST /auth: ${response.status} ${response.statusText}`);
    
    const data = await response.text();
    try {
      const jsonData = JSON.parse(data);
      console.log(`   Response:`, JSON.stringify(jsonData, null, 2));
    } catch {
      console.log(`   Response: ${data}`);
    }
  } catch (error) {
    console.log(`   POST /auth: ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test points API token endpoint
async function testPointsAuth() {
  console.log('🎁 Test 3: Testing wc-points-rewards/v1/auth/token...');
  
  const testCredentials = {
    email: 'test@example.com',
    password: 'test123'
  };

  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/wc-points-rewards/v1/auth/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testCredentials)
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    const data = await response.text();
    try {
      const jsonData = JSON.parse(data);
      console.log(`   Response:`, JSON.stringify(jsonData, null, 2));
    } catch {
      console.log(`   Response: ${data}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test settings endpoint
async function testSettings() {
  console.log('⚙️  Test 4: Getting points/rewards settings...');
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/wc-points-rewards/v1/settings`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const settings = await response.json();
      console.log(`   ✅ Settings:`, JSON.stringify(settings, null, 2));
    } else {
      const error = await response.text();
      console.log(`   Response: ${error}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Update the POSV1 configuration suggestions
async function suggestConfig() {
  console.log('💡 Suggested POSV1 Configuration:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  
  console.log('Update your POSV1 API routes to use the existing endpoints:\n');
  
  console.log('1. For stores list:');
  console.log('   GET /wp-json/flora-pos/v1/stores\n');
  
  console.log('2. For authentication:');
  console.log('   POST /wp-json/wc-points-rewards/v1/auth/token');
  console.log('   (This appears to be the authentication endpoint)\n');
  
  console.log('3. For points/rewards:');
  console.log('   GET /wp-json/wc-points-rewards/v1/user/{user_id}/balance');
  console.log('   POST /wp-json/wc-points-rewards/v1/user/{user_id}/adjust');
  console.log('   GET /wp-json/wc-points-rewards/v1/settings\n');
  
  console.log('4. Update POSV1/.env.local:');
  console.log('   NEXT_PUBLIC_WORDPRESS_URL=http://api.floradistro.com');
  console.log('   WC_CONSUMER_KEY=ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5');
  console.log('   WC_CONSUMER_SECRET=cs_38194e74c7ddc5d72b6c32c70485728e7e529678\n');
}

// Run all tests
async function runAllTests() {
  await testStores();
  await testAuth();
  await testPointsAuth();
  await testSettings();
  await suggestConfig();
}

// Execute tests
runAllTests().catch(console.error); 