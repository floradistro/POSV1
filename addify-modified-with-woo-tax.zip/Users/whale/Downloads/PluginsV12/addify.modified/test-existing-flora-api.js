#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';

// Create basic auth header
const authHeader = 'Basic ' + Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64');

console.log('🌺 Testing Existing Flora API Endpoints:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Test Flora namespace endpoints
async function testFloraEndpoints() {
  console.log('🌸 Testing flora/v1 namespace endpoints...');
  
  const endpoints = [
    '/wp-json/flora/v1',
    '/wp-json/flora/v1/auth/login',
    '/wp-json/flora/v1/stores',
    '/wp-json/flora/v1/products',
    '/wp-json/flora/v1/inventory',
    '/wp-json/flora/v1/locations'
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
      
      if (response.ok && endpoint === '/wp-json/flora/v1') {
        const data = await response.json();
        if (data.routes) {
          console.log('   Available routes:');
          Object.keys(data.routes).forEach(route => {
            console.log(`      - ${route}`);
          });
        }
      }
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test Flora POS namespace endpoints
async function testFloraPosEndpoints() {
  console.log('🏪 Testing flora-pos/v1 namespace endpoints...');
  
  const endpoints = [
    '/wp-json/flora-pos/v1',
    '/wp-json/flora-pos/v1/auth/login',
    '/wp-json/flora-pos/v1/stores',
    '/wp-json/flora-pos/v1/terminals',
    '/wp-json/flora-pos/v1/session'
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
      
      if (response.ok && endpoint === '/wp-json/flora-pos/v1') {
        const data = await response.json();
        if (data.routes) {
          console.log('   Available routes:');
          Object.keys(data.routes).forEach(route => {
            console.log(`      - ${route}`);
          });
        }
      }
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test WC Points Rewards endpoints
async function testPointsRewardsEndpoints() {
  console.log('🎁 Testing wc-points-rewards/v1 namespace endpoints...');
  
  const endpoints = [
    '/wp-json/wc-points-rewards/v1',
    '/wp-json/wc-points-rewards/v1/points',
    '/wp-json/wc-points-rewards/v1/balance',
    '/wp-json/wc-points-rewards/v1/config'
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
      
      if (response.ok && endpoint === '/wp-json/wc-points-rewards/v1') {
        const data = await response.json();
        if (data.routes) {
          console.log('   Available routes:');
          Object.keys(data.routes).forEach(route => {
            console.log(`      - ${route}`);
          });
        }
      }
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test login with flora-pos endpoint
async function testFloraLogin() {
  console.log('🔐 Testing flora-pos login endpoint...');
  
  const testCredentials = {
    email: 'test@example.com',
    password: 'test123',
    store_id: 1,
    terminal_id: 'terminal-1'
  };

  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(testCredentials)
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    const data = await response.text();
    try {
      const jsonData = JSON.parse(data);
      console.log(`   Response:`, JSON.stringify(jsonData, null, 2));
    } catch {
      console.log(`   Response: ${data}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Run all tests
async function runAllTests() {
  await testFloraEndpoints();
  await testFloraPosEndpoints();
  await testPointsRewardsEndpoints();
  await testFloraLogin();
  
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📋 Summary:');
  console.log('\nIt appears there are already Flora POS endpoints available.');
  console.log('You may need to:');
  console.log('1. Check if the existing flora-pos/v1 endpoints provide the functionality you need');
  console.log('2. Update POSV1 to use the existing endpoints instead');
  console.log('3. Or ensure the modified plugins are properly uploaded and activated');
}

// Execute tests
runAllTests().catch(console.error); 