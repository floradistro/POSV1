#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';

// Create basic auth header
const authHeader = 'Basic ' + Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64');

console.log('🔐 Testing Flora POS Authentication:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Test flora-pos/v1/auth with different payloads
async function testFloraPosAuth() {
  console.log('🌺 Testing flora-pos/v1/auth endpoint...\n');
  
  // Test 1: Standard credentials
  console.log('Test 1: Standard login payload');
  const payload1 = {
    email: 'test@example.com',
    password: 'test123',
    store_id: 30,  // Charlotte Monroe from the stores list
    terminal_id: 'terminal-1'
  };
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(payload1)
    });
    
    console.log(`Status: ${response.status}`);
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  } catch (error) {
    console.log('Error:', error.message);
  }
  
  console.log('\n---\n');
  
  // Test 2: Username instead of email
  console.log('Test 2: Username-based payload');
  const payload2 = {
    username: 'test@example.com',
    password: 'test123',
    store_id: 30,
    terminal_id: 'terminal-1'
  };
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(payload2)
    });
    
    console.log(`Status: ${response.status}`);
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  } catch (error) {
    console.log('Error:', error.message);
  }
  
  console.log('\n---\n');
  
  // Test 3: Minimal payload
  console.log('Test 3: Minimal payload (just credentials)');
  const payload3 = {
    username: 'test@example.com',
    password: 'test123'
  };
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/flora-pos/v1/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(payload3)
    });
    
    console.log(`Status: ${response.status}`);
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  } catch (error) {
    console.log('Error:', error.message);
  }
}

// Test wc-points-rewards auth
async function testPointsAuth() {
  console.log('\n\n🎁 Testing wc-points-rewards/v1/auth/token endpoint...\n');
  
  const payload = {
    username: 'test@example.com',
    password: 'test123'
  };
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/wc-points-rewards/v1/auth/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    
    console.log(`Status: ${response.status}`);
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  } catch (error) {
    console.log('Error:', error.message);
  }
}

// Update POSV1 login route
function showUpdatedLoginRoute() {
  console.log('\n\n📝 Updated POSV1 Login Route:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  
  console.log('Update POSV1/src/app/api/auth/login/route.ts to use flora-pos endpoint:\n');
  
  console.log(`
// Call the flora-pos authentication endpoint
const authResponse = await fetch(\`\${WORDPRESS_URL}/wp-json/flora-pos/v1/auth\`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Basic ' + Buffer.from(\`\${WC_CONSUMER_KEY}:\${WC_CONSUMER_SECRET}\`).toString('base64')
  },
  body: JSON.stringify({
    username: email,  // or 'email' depending on what works
    password,
    store_id: storeId,
    terminal_id: terminalId
  })
});
  `);
  
  console.log('\nAnd update the stores endpoint to:');
  console.log('GET /wp-json/flora-pos/v1/stores (already working!)');
}

// Run all tests
async function runAllTests() {
  await testFloraPosAuth();
  await testPointsAuth();
  showUpdatedLoginRoute();
}

// Execute tests
runAllTests().catch(console.error); 