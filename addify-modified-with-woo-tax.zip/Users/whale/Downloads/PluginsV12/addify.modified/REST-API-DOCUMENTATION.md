# Addify Multi Inventory Headless REST API Documentation

This document outlines the comprehensive REST API endpoints added to the Addify Multi Inventory Management plugin for headless/AI-controlled inventory management.

## Base URL
All endpoints are prefixed with: `/wp-json/wc/v3/addify_headless_inventory/`

## Authentication
All endpoints require WooCommerce management permissions. Use WordPress REST API authentication methods (Application Passwords, JWT, etc.).

## Locations Management

### Get All Locations
**GET** `/locations`

Returns all inventory locations.

**Response:**
```json
[
  {
    "id": 1,
    "name": "Main Warehouse",
    "slug": "main-warehouse",
    "description": "Primary storage facility",
    "address": "123 Main St, City, State",
    "manager": "John Doe",
    "phone": "+1-555-0123"
  }
]
```

### Get Single Location
**GET** `/locations/{id}`

Returns details for a specific location.

### Create Location
**POST** `/locations`

Creates a new inventory location.

**Request Body:**
```json
{
  "name": "New Warehouse",
  "description": "Secondary storage facility",
  "address": "456 Oak Ave, City, State",
  "manager": "Jane Smith",
  "phone": "+1-555-0456"
}
```

### Update Location
**PUT** `/locations/{id}`

Updates an existing location.

### Delete Location
**DELETE** `/locations/{id}`

Deletes a location (removes all associated inventory).

## Product Inventory Management

### Get Product Inventory
**GET** `/products/{product_id}/inventory`

Returns all inventory records for a specific product across all locations.

**Response:**
```json
[
  {
    "id": 123,
    "name": "Inventory for Location 1",
    "product_id": 456,
    "location_id": 1,
    "location_name": "Main Warehouse",
    "quantity": 50,
    "created_date": "2024-01-15 10:30:00"
  }
]
```

### Create Product Inventory
**POST** `/products/{product_id}/inventory`

Creates inventory for a product at a specific location. If an inventory already exists for the same product-location combination, it will be updated instead of creating a duplicate. Supports decimal quantities for weight-based products.

**Request Body:**
```json
{
  "location_id": 1,
  "quantity": 100.5,
  "name": "Main Stock"
}
```

**Response (New Inventory):**
```json
{
  "id": 123,
  "name": "Main Stock",
  "product_id": 456,
  "location_id": 1,
  "location_name": "Main Warehouse",
  "quantity": 100.5,
  "created_date": "2024-01-15 10:30:00"
}
```

**Response (Updated Existing Inventory):**
```json
{
  "id": 123,
  "name": "Main Stock",
  "product_id": 456,
  "location_id": 1,
  "location_name": "Main Warehouse",
  "quantity": 100.5,
  "created_date": "2024-01-15 10:30:00",
  "updated": true,
  "previous_quantity": 50
}
```

### Get Inventory Item
**GET** `/products/{product_id}/inventory/{inventory_id}`

Returns details for a specific inventory item.

### Update Inventory Item
**PUT** `/products/{product_id}/inventory/{inventory_id}`

Updates an inventory item. Supports decimal quantities for weight-based products.

**Request Body:**
```json
{
  "quantity": 75.25,
  "location_id": 2,
  "name": "Updated Inventory"
}
```

### Delete Inventory Item
**DELETE** `/products/{product_id}/inventory/{inventory_id}`

Deletes an inventory item.

## Stock Management

### Update Stock
**POST** `/stock/update`

Updates stock quantity for a specific inventory item. Supports decimal quantities for weight-based products.

**Request Body:**
```json
{
  "inventory_id": 123,
  "quantity": 25.5,
  "operation": "add"
}
```

**Operations:**
- `set`: Set exact quantity
- `add`: Add to current quantity
- `subtract`: Subtract from current quantity

**Note:** Quantity now supports decimal values (floats) for deli-style weight-based products (e.g., 3.5 for 3.5 grams)

**Response:**
```json
{
  "inventory_id": 123,
  "previous_quantity": 50,
  "new_quantity": 75,
  "operation": "add"
}
```

### Bulk Update Stock
**POST** `/stock/bulk-update`

Updates multiple inventory items in a single request. Supports decimal quantities for weight-based products.

**Request Body:**
```json
{
  "updates": [
    {
      "inventory_id": 123,
      "quantity": 10.5,
      "operation": "add"
    },
    {
      "inventory_id": 124,
      "quantity": 50.75,
      "operation": "set"
    }
  ]
}
```

### Transfer Stock
**POST** `/stock/transfer`

Transfers stock between locations for the same product. Supports decimal quantities for weight-based products.

**Request Body:**
```json
{
  "product_id": 456,
  "from_location_id": 1,
  "to_location_id": 2,
  "quantity": 20.5
}
```

**Response:**
```json
{
  "product_id": 456,
  "from_location": 1,
  "to_location": 2,
  "quantity": 20,
  "from_remaining": 30,
  "to_new_total": 45
}
```

### Convert Stock
**POST** `/stock/convert`

Converts stock from one product to another (e.g., flower to pre-rolls). Perfect for deli-style conversions.

**Request Body:**
```json
{
  "from_product_id": 123,
  "to_product_id": 456,
  "from_quantity": 3.5,
  "to_quantity": 5,
  "location_id": 1,
  "notes": "Converted 3.5g flower to 5 pre-rolls"
}
```

**Response:**
```json
{
  "from_product_id": 123,
  "from_product_name": "Blue Dream Flower",
  "to_product_id": 456,
  "to_product_name": "Blue Dream Pre-rolls",
  "from_quantity": 3.5,
  "to_quantity": 5,
  "location_id": 1,
  "from_remaining": 108.5,
  "to_new_total": 25,
  "conversion_ratio": 1.4286,
  "notes": "Converted 3.5g flower to 5 pre-rolls"
}
```

## Reporting & Analytics

### Get Location Stock
**GET** `/locations/{location_id}/stock`

Returns all stock items for a specific location.

**Response:**
```json
[
  {
    "inventory_id": 123,
    "product_id": 456,
    "product_name": "Sample Product",
    "product_sku": "SKU-001",
    "quantity": 50
  }
]
```

### Get Low Stock Items
**GET** `/stock/low-stock?threshold=10`

Returns inventory items below the specified threshold.

**Query Parameters:**
- `threshold` (optional): Stock level threshold (default: 10)

**Response:**
```json
[
  {
    "inventory_id": 123,
    "product_id": 456,
    "product_name": "Sample Product",
    "product_sku": "SKU-001",
    "location_id": 1,
    "location_name": "Main Warehouse",
    "quantity": 5
  }
]
```

## AI/Cursor Integration Examples

### Add Stock to Location
```bash
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/update" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "inventory_id": 123,
    "quantity": 50,
    "operation": "add"
  }'
```

### Transfer Stock Between Locations
```bash
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/transfer" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "product_id": 456,
    "from_location_id": 1,
    "to_location_id": 2,
    "quantity": 25
  }'
```

### Create New Location
```bash
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/locations" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Downtown Store",
    "address": "789 Downtown Blvd",
    "manager": "Mike Johnson",
    "phone": "+1-555-0789"
  }'
```

### Bulk Stock Update
```bash
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/bulk-update" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "updates": [
      {"inventory_id": 123, "quantity": 100, "operation": "set"},
      {"inventory_id": 124, "quantity": 50, "operation": "add"},
      {"inventory_id": 125, "quantity": 10, "operation": "subtract"}
    ]
  }'
```

## Error Handling

All endpoints return standard HTTP status codes:

- `200`: Success
- `201`: Created
- `400`: Bad Request (validation errors)
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not Found
- `500`: Internal Server Error

Error responses include details:
```json
{
  "code": "invalid_inventory",
  "message": "Invalid inventory ID.",
  "data": {
    "status": 404
  }
}
```

## Rate Limiting

No rate limiting is implemented by default. Consider implementing rate limiting at the server level for production use.

## Security Considerations

1. All endpoints require WooCommerce management permissions
2. Input validation is performed on all parameters
3. SQL injection protection through WordPress APIs
4. Nonce verification for CSRF protection (when applicable)

## Product Configuration

New product meta fields have been added to support deli-style inventory:

### Product Meta Fields
- **mli_product_type**: `'weight'` or `'quantity'` - Determines if product is tracked by weight (grams) or units
- **mli_weight_options**: Comma-separated weight options (e.g., "0.5,1,3.5,7,14,28")
- **mli_preroll_conversion**: Grams per pre-roll (default: 0.7)
- **mli_pricing_tiers**: JSON object with tier pricing:
  - For weight: `{"1":10,"3.5":8.5,"7":7.5,"14":7,"28":6.5}` (grams:price_per_gram)
  - For quantity: `{"1":15,"5":14,"10":13}` (quantity:price_per_unit)

These fields are managed in the WooCommerce product edit screen under the Inventory tab when Multi Inventory is enabled.

## Integration Notes

- All existing Addify functionality remains unchanged
- New endpoints work alongside existing admin interface
- Stock updates trigger WooCommerce stock management hooks
- Compatible with WooCommerce REST API authentication methods
- Supports WordPress multisite installations

## Weight-Based Inventory Management

The API now fully supports decimal quantities for deli-style, weight-based products:

### Example: Deducting Weight from Flower Inventory
```bash
# Initial stock: 112 grams
# Customer purchases: 3.5 grams

curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/update" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "inventory_id": 123,
    "quantity": 3.5,
    "operation": "subtract"
  }'
```

### Example: Bulk Weight Updates
```bash
# Update multiple weight-based products
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/bulk-update" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "updates": [
      {"inventory_id": 123, "quantity": 28.5, "operation": "subtract"},
      {"inventory_id": 124, "quantity": 14.25, "operation": "subtract"},
      {"inventory_id": 125, "quantity": 7.75, "operation": "subtract"}
    ]
  }'
```

### Example: Flower to Pre-roll Conversion
```bash
# Convert 3.5g of flower into 5 pre-rolls (0.7g each)
curl -X POST "https://yoursite.com/wp-json/wc/v3/addify_headless_inventory/stock/convert" \
  -H "Authorization: Basic YOUR_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "from_product_id": 123,
    "to_product_id": 456,
    "from_quantity": 3.5,
    "to_quantity": 5,
    "location_id": 1,
    "notes": "Daily pre-roll production"
  }'
```

### Supported Decimal Operations
- All quantity fields now accept decimal values
- Supports fractional additions, subtractions, and transfers
- Perfect for cannabis flower (grams), concentrates (grams), or any weight-based inventory
- Includes product-to-product conversions for deli-style operations

## Support

For issues related to the headless API extension, ensure:
1. WooCommerce is active and updated
2. Addify Multi Inventory plugin is active
3. User has appropriate permissions
4. WordPress REST API is enabled

This API extension provides complete programmatic control over inventory management while preserving all existing functionality. 