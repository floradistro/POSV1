# Addify Multi-Location Inventory - Tax Implementation

## Overview
This implementation adds store-level tax configuration to the Addify Multi-Location Inventory plugin. Each location can have unique tax rates that are automatically applied in the POS system.

## Features Added

### 1. Tax Configuration UI
- Added to location edit/create screens in WordPress admin
- Located under **WooCommerce > Multi Inventory > Locations**
- Supports multiple tax rates per location
- Tax types: Percentage or Fixed Amount
- Compound tax support (tax on tax)

### 2. REST API Endpoints

#### Get Tax Rates for a Location
```
GET /wp-json/wc/v3/addify_multi_inventory/location/{location_id}/tax-rates
```

Response:
```json
{
  "location_id": 31,
  "location_name": "Charlotte Nations Ford",
  "tax_rates": [
    {
      "name": "NC State Tax",
      "rate": 4.75,
      "type": "percentage",
      "compound": "no"
    },
    {
      "name": "Cannabis Excise Tax",
      "rate": 15,
      "type": "percentage",
      "compound": "yes"
    }
  ],
  "total_rate": 20.46
}
```

#### Get All Locations Tax Rates
```
GET /wp-json/wc/v3/addify_multi_inventory/locations/tax-rates
```

## Files Modified

### 1. REST API Controller
**File:** `/rest-api/controllers/af-multi-inventory-api-controller.php`
- Added tax rate endpoints registration
- Added methods: `get_location_tax_rates()`, `get_all_locations_tax_rates()`
- Added tax calculation method: `calculate_total_tax_rate()`
- Added tax rates schema

### 2. Location Taxonomy
**File:** `/includes/admin/taxonomy/class-addify-mli-taxonomy.php`
- Added tax configuration UI in both add and edit forms
- Added JavaScript for dynamic tax rate management
- Added save functionality for tax rates
- Tax rates stored as term meta: `af_mli_tax_rates`

## Installation Instructions

1. **Upload Plugin**
   - Upload the modified addify plugin to your WordPress installation

2. **Activate Plugin**
   - Deactivate and reactivate the plugin to register new routes:
   ```bash
   wp plugin deactivate addify-multi-location-inventory
   wp plugin activate addify-multi-location-inventory
   ```

3. **Flush Rewrite Rules**
   ```bash
   wp rewrite flush
   ```

4. **Configure Tax Rates**
   - Go to WooCommerce > Multi Inventory > Locations
   - Edit each location
   - Scroll to "Tax Configuration" section
   - Add your tax rates

## Tax Configuration Examples

### Cannabis Dispensary (NC)
- State Tax: 4.75% (non-compound)
- County Tax: 2.5% (non-compound)
- Cannabis Excise Tax: 15% (compound)

### Regular Retail (TN)
- State Tax: 7% (non-compound)
- Local Tax: 2.5% (non-compound)

## Compound Tax Calculation
```
Non-compound total = subtotal × (sum of non-compound rates / 100)
Compound base = subtotal + non-compound total
Compound total = compound base × (compound rate / 100)
Total tax = non-compound total + compound total
```

## POS Integration
The POS system will:
1. Fetch tax rates when user logs into a location
2. Calculate taxes based on the cart subtotal
3. Display tax breakdown in the cart
4. Include tax metadata in orders

## Testing
1. Configure tax rates for a location
2. Test the API endpoint: `/wp-json/wc/v3/addify_multi_inventory/location/{id}/tax-rates`
3. Login to POS with that location
4. Add items to cart and verify tax calculations

## Troubleshooting

### API Returns 404
- Ensure plugin is activated
- Flush rewrite rules
- Check REST API is accessible
- Verify WooCommerce API credentials

### Tax Rates Not Saving
- Check user has permission to edit terms
- Verify nonce field is present
- Check PHP error logs

### Wrong Tax Calculations
- Verify compound setting
- Check rate format (8.5 not 0.085)
- Review calculation order 