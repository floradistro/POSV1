#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';

// Create basic auth header
const authHeader = 'Basic ' + Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64');

console.log('🔍 Testing POS Integration with:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Test 1: Get public stores
async function testPublicStores() {
  console.log('📍 Test 1: Fetching public stores...');
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/addify-mli/v1/stores/public`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const stores = await response.json();
      console.log(`   ✅ Found ${stores.length} stores:`);
      stores.forEach(store => {
        console.log(`      - Store #${store.id}: ${store.name}`);
      });
    } else {
      const error = await response.text();
      console.log(`   ❌ Error: ${error}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test 2: Check WooCommerce API
async function testWooCommerceAPI() {
  console.log('🛒 Test 2: Testing WooCommerce API access...');
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/wc/v3/system_status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log(`   ✅ WooCommerce Version: ${data.environment.version}`);
      console.log(`   ✅ Site Name: ${data.environment.site_name}`);
    } else {
      console.log(`   ❌ Error: Unable to access WooCommerce API`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test 3: Check if Multi-Location Inventory endpoints exist
async function testMultiInventoryEndpoints() {
  console.log('📦 Test 3: Checking Multi-Location Inventory endpoints...');
  
  const endpoints = [
    '/wp-json/addify-mli/v1/auth/login',
    '/wp-json/addify-mli/v1/stores/public',
    '/wp-json/wc/v3/addify_headless_inventory/locations'
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: endpoint.includes('login') ? 'POST' : 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test 4: Check Points & Rewards endpoints
async function testPointsRewardsEndpoints() {
  console.log('🎁 Test 4: Checking Points & Rewards endpoints...');
  
  const endpoints = [
    '/wp-json/wc-pos/v1/store-context',
    '/wp-json/flora-rewards/v1/points/balance',
    '/wp-json/flora-rewards/v1/config'
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test 5: Attempt test login
async function testLogin() {
  console.log('🔐 Test 5: Testing POS login endpoint...');
  
  const testCredentials = {
    email: 'test@example.com',
    password: 'test123',
    store_id: 1,
    terminal_id: 'terminal-1'
  };

  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/addify-mli/v1/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      body: JSON.stringify(testCredentials)
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    const data = await response.json();
    if (response.status === 401) {
      console.log(`   ℹ️  Expected result: Authentication failed (test credentials)`);
      console.log(`   Message: ${data.message || data.error}`);
    } else if (response.ok) {
      console.log(`   ✅ Login endpoint is working!`);
    } else {
      console.log(`   ⚠️  Unexpected response:`, data);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Run all tests
async function runAllTests() {
  await testPublicStores();
  await testWooCommerceAPI();
  await testMultiInventoryEndpoints();
  await testPointsRewardsEndpoints();
  await testLogin();
  
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('✨ Testing complete!');
  console.log('\nNext steps:');
  console.log('1. Update POSV1/.env.local with these credentials');
  console.log('2. Create a WordPress user with POS access in the admin panel');
  console.log('3. Assign the user to specific stores');
  console.log('4. Test login with real credentials');
}

// Execute tests
runAllTests().catch(console.error); 