# POS Integration Guide

## Overview

This guide explains how the Point of Sale (POS) system integrates with the Addify Multi-Location Inventory plugin and the Flora Points & Rewards plugin.

## Architecture

### 1. **Addify Multi-Location Inventory Plugin**
- Handles all POS authentication and session management
- Manages stores/locations and terminals
- Provides REST API endpoints for POS operations

### 2. **Flora Points & Rewards Plugin**
- Integrates with Addify for store context
- Manages customer points and rewards
- Respects store context for multi-location operations

### 3. **POSV1 Next.js Application**
- Frontend POS interface
- Communicates with WordPress via REST APIs
- Handles authentication through Addify endpoints

## Key Features Added

### Addify Plugin Enhancements

1. **New REST API Endpoints**:
   - `/wp-json/addify-mli/v1/auth/login` - POS user authentication
   - `/wp-json/addify-mli/v1/stores/public` - Get public store list
   - `/wp-json/addify-mli/v1/terminals/{store_id}` - Manage terminals
   - `/wp-json/addify-mli/v1/session` - Session management

2. **Database Tables**:
   - `wp_af_mli_terminals` - Store terminal registry
   - `wp_af_mli_pos_sessions` - Active POS sessions

3. **User Management**:
   - Store assignments via user meta
   - POS employee capability
   - Admin interface for user-store mapping

### Points Plugin Integration

1. **Store Context Support**:
   - Reads Addify POS session for store context
   - Filters points calculations by store
   - New endpoint: `/wp-json/wc-pos/v1/store-context`

2. **Multi-Store Points**:
   - Points can be filtered by store location
   - Hooks for custom store-based points logic

## Setup Instructions

### 1. Configure WordPress Users

1. Navigate to Users > All Users in WordPress admin
2. Edit a user who should have POS access
3. In the "POS Store Access" section:
   - Check "Allow POS Access"
   - Select which stores the user can access
4. Save the user

### 2. Configure Stores

1. Navigate to Multi Location Inventory > Locations
2. Create store locations as needed
3. Each location will be available in the POS login dropdown

### 3. Configure POS Settings

1. Navigate to Multi Location Inventory > POS Settings
2. Configure:
   - Enable POS Mode
   - Session timeout
   - Terminal settings

### 4. Environment Variables

In your POSV1 `.env.local` file, ensure:

```env
NEXT_PUBLIC_WORDPRESS_URL=https://your-wordpress-site.com
WC_CONSUMER_KEY=your_consumer_key
WC_CONSUMER_SECRET=your_consumer_secret
```

## Authentication Flow

1. User selects store and terminal on login page
2. Credentials sent to `/wp-json/addify-mli/v1/auth/login`
3. WordPress validates:
   - User credentials
   - POS access capability
   - Store access permissions
4. Session created with store/terminal context
5. JWT token returned for subsequent requests

## API Usage Examples

### Login
```javascript
POST /api/auth/login
{
  "email": "user@example.com",
  "password": "password",
  "storeId": 30,
  "terminalId": "terminal-1"
}
```

### Get Stores
```javascript
GET /api/stores/public
```

### Get Store Context (from Points plugin)
```javascript
GET /wp-json/wc-pos/v1/store-context
Authorization: Bearer <token>
```

## Extending the Integration

### Adding Store-Specific Points Rules

```php
add_filter('wc_points_rewards_user_points_balance', function($balance, $user_id, $store_context) {
    if ($store_context && $store_context['store_id'] == 30) {
        // Custom logic for store 30
        $balance = $balance * 1.1; // 10% bonus for this store
    }
    return $balance;
}, 10, 3);
```

### Custom Terminal Actions

```php
add_action('af_mli_terminal_login', function($user_id, $store_id, $terminal_id) {
    // Log terminal access or perform custom actions
}, 10, 3);
```

## Troubleshooting

### Common Issues

1. **Login fails with "No user found"**
   - Ensure user is a WordPress user, not just a WooCommerce customer
   - Check that user has 'pos_employee' capability

2. **Stores not showing in dropdown**
   - Verify locations exist in Multi Location Inventory > Locations
   - Check that locations are not set as 'inactive'

3. **"User does not have access to this store"**
   - Edit user profile and assign stores in POS Store Access section
   - Administrators have access to all stores by default

## Security Considerations

1. **Authentication**: Uses WordPress user system with additional POS capabilities
2. **Session Management**: Sessions expire after configured timeout
3. **Store Isolation**: Users can only access assigned stores
4. **API Security**: All endpoints require proper authentication

## Future Enhancements

1. **Real-time Updates**: WebSocket support for live inventory updates
2. **Offline Mode**: Local storage with sync capabilities
3. **Advanced Reporting**: Store-specific sales and inventory reports
4. **Mobile App**: Native mobile POS applications 