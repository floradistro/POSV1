#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';

console.log('🔍 Finding Authentication Endpoints:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Get all available routes
async function findAuthEndpoints() {
  console.log('📝 Fetching all available REST routes...\n');
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      console.log('❌ Failed to fetch REST API index');
      return;
    }

    const data = await response.json();
    
    // Look for auth-related routes
    console.log('🔐 Authentication-related endpoints found:\n');
    
    if (data.routes) {
      const authRoutes = [];
      
      // Search through all routes
      Object.keys(data.routes).forEach(route => {
        if (route.includes('auth') || 
            route.includes('login') || 
            route.includes('token') ||
            route.includes('user') && route.includes('authenticate')) {
          authRoutes.push({
            route: route,
            methods: data.routes[route].methods
          });
        }
      });
      
      if (authRoutes.length > 0) {
        authRoutes.forEach(({route, methods}) => {
          console.log(`   ${route}`);
          console.log(`   Methods: ${methods.join(', ')}`);
          console.log('');
        });
      } else {
        console.log('   ❌ No obvious authentication endpoints found');
      }
    }
    
    // Check specific namespaces for auth
    console.log('\n🔍 Checking each namespace for authentication routes...\n');
    
    const namespacesToCheck = [
      'jwt-auth/v1',
      'wc/v3',
      'flora-pos/v1',
      'flora/v1',
      'wc-points-rewards/v1'
    ];
    
    for (const namespace of namespacesToCheck) {
      if (data.namespaces && data.namespaces.includes(namespace)) {
        console.log(`📦 Namespace: ${namespace}`);
        
        try {
          const nsResponse = await fetch(`${WORDPRESS_URL}/wp-json/${namespace}`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json'
            }
          });
          
          if (nsResponse.ok) {
            const nsData = await nsResponse.json();
            if (nsData.routes) {
              const nsAuthRoutes = Object.keys(nsData.routes).filter(route => 
                route.includes('auth') || 
                route.includes('login') || 
                route.includes('token')
              );
              
              if (nsAuthRoutes.length > 0) {
                nsAuthRoutes.forEach(route => {
                  console.log(`   ✅ ${route}`);
                });
              } else {
                console.log(`   - No auth routes found`);
              }
            }
          }
        } catch (error) {
          console.log(`   ❌ Error fetching namespace`);
        }
        console.log('');
      }
    }
    
    // JWT Auth check
    console.log('\n🔑 JWT Authentication Check:');
    if (data.namespaces && data.namespaces.includes('jwt-auth/v1')) {
      console.log('   ✅ JWT Auth plugin is installed');
      console.log('   Try: POST /wp-json/jwt-auth/v1/token');
      console.log('   Body: { "username": "email@example.com", "password": "password" }');
    } else {
      console.log('   ❌ JWT Auth plugin not detected');
    }
    
  } catch (error) {
    console.log(`❌ Network error: ${error.message}`);
  }
}

// Test JWT auth if available
async function testJWTAuth() {
  console.log('\n\n🔐 Testing JWT Authentication...\n');
  
  const testCredentials = {
    username: 'test@example.com',
    password: 'test123'
  };
  
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/jwt-auth/v1/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testCredentials)
    });
    
    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    const data = await response.text();
    try {
      const jsonData = JSON.parse(data);
      console.log(`   Response:`, JSON.stringify(jsonData, null, 2));
    } catch {
      console.log(`   Response: ${data}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
}

// Suggest configuration
function suggestConfig() {
  console.log('\n\n💡 Authentication Configuration for POSV1:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  
  console.log('Based on the available endpoints, you have two options:\n');
  
  console.log('Option 1: Use JWT Authentication (if available)');
  console.log('   - Install/configure JWT Authentication for WP REST API plugin');
  console.log('   - Use POST /wp-json/jwt-auth/v1/token for login');
  console.log('   - Include JWT token in subsequent requests\n');
  
  console.log('Option 2: Upload the modified plugins');
  console.log('   - Upload the modified addify.modified plugin');
  console.log('   - This will add /wp-json/addify-mli/v1/auth/login endpoint');
  console.log('   - Provides store-specific authentication\n');
  
  console.log('Option 3: Use Basic Auth with WooCommerce');
  console.log('   - Create WordPress users with WooCommerce access');
  console.log('   - Use Basic Authentication with consumer key/secret');
  console.log('   - No separate login endpoint needed');
}

// Run all tests
async function runAllTests() {
  await findAuthEndpoints();
  await testJWTAuth();
  suggestConfig();
}

// Execute tests
runAllTests().catch(console.error); 