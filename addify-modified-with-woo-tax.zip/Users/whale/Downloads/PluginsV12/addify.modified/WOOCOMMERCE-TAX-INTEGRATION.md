# WooCommerce Tax Integration for Addify Multi Location Inventory

## Overview

This integration allows you to use WooCommerce's native tax system with the Addify Multi Location Inventory plugin. Instead of managing custom tax rates, you can now assign existing WooCommerce tax rates to each location.

## Benefits

1. **Native WooCommerce Integration**: Taxes are properly recorded in WooCommerce orders (not as fees)
2. **Tax Reporting**: Works with WooCommerce tax reports and analytics
3. **Tax Classes**: Support for different tax classes (Standard, Reduced Rate, Zero Rate, etc.)
4. **Compound Taxes**: Full support for compound tax calculations
5. **Shipping Taxes**: Option to apply taxes to shipping costs

## Configuration

### Step 1: Set Up WooCommerce Tax Rates

1. Go to **WooCommerce → Settings → Tax**
2. Enable taxes by checking "Enable tax rates and calculations"
3. Configure your tax options (prices inclusive/exclusive of tax, etc.)
4. Click on "Standard rates" (or other tax classes) to add tax rates
5. Add tax rates for each jurisdiction:
   - **Country code**: US
   - **State code**: NC (or your state)
   - **Postcode/ZIP**: Leave blank to apply to all postcodes
   - **City**: Leave blank to apply to all cities
   - **Tax rate %**: Enter the percentage (e.g., 6.75)
   - **Tax name**: Enter a descriptive name (e.g., "NC State Tax")
   - **Priority**: Set priority for tax calculation order
   - **Compound**: Check if this tax should be calculated on top of other taxes
   - **Shipping**: Check if this tax applies to shipping

### Step 2: Assign Tax Rates to Locations

1. Go to **WooCommerce → Multi Inventory → Locations**
2. Edit a location
3. Scroll to the "WooCommerce Tax Rates" section
4. Check the tax rates that should apply to this location
5. You can use the "Select all" checkbox to quickly assign all rates in a tax class
6. Save the location

## API Endpoints

The plugin provides REST API endpoints to fetch location-specific tax rates:

### Get Tax Rates for a Specific Location
```
GET /wp-json/wc/v3/addify_headless_inventory/location/{location_id}/tax-rates
```

Response:
```json
{
  "location_id": 32,
  "location_name": "Blowing Rock",
  "tax_rates": [
    {
      "id": 1,
      "name": "NC State Tax",
      "rate": 4.75,
      "compound": "no",
      "shipping": "yes",
      "class": ""
    },
    {
      "id": 2,
      "name": "County Tax",
      "rate": 2.5,
      "compound": "no",
      "shipping": "yes",
      "class": ""
    }
  ],
  "total_rate": 7.25
}
```

### Get Tax Rates for All Locations
```
GET /wp-json/wc/v3/addify_headless_inventory/locations/tax-rates
```

## POS Integration

The POS system automatically:
1. Fetches the assigned WooCommerce tax rates for the logged-in location
2. Calculates taxes based on these rates (including compound tax logic)
3. Displays individual tax components in the cart
4. Includes tax information in the order metadata

## Order Recording

When orders are created through the POS:
- Tax totals are recorded in order metadata
- Individual tax breakdowns are saved
- WooCommerce tax rate IDs are included for proper reporting

## Troubleshooting

### Tax rates not showing in location edit screen
- Ensure you have created tax rates in WooCommerce → Settings → Tax
- Check that taxes are enabled in WooCommerce settings

### Tax rates not applying in POS
- Verify the location has tax rates assigned
- Check the API endpoint is returning the correct rates
- Ensure the POS is fetching rates for the correct location ID

### Orders not showing taxes in WooCommerce admin
- This integration saves tax information as metadata
- WooCommerce requires server-side tax calculation for native tax line items
- Consider implementing a server-side order creation endpoint that applies taxes

## Migration from Custom Tax Rates

If you were using the custom tax rate system:
1. Note down your existing tax configurations
2. Create equivalent tax rates in WooCommerce
3. Assign the new WooCommerce tax rates to your locations
4. The old custom tax rates will be ignored once WooCommerce rates are assigned 