<?php
/**
 * Addify Multi Inventory POS Settings
 * 
 * Manages POS settings and user-store assignments in admin.
 *
 * @package Addify\MultiLocationInventory
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * POS Settings class.
 */
class Af_MLI_POS_Settings {

    /**
     * Constructor.
     */
    public function __construct() {
        // Add settings to existing Multi Location Inventory menu
        add_action('admin_menu', array($this, 'add_pos_settings_submenu'), 99);
        
        // Add user profile fields
        add_action('show_user_profile', array($this, 'add_user_store_fields'));
        add_action('edit_user_profile', array($this, 'add_user_store_fields'));
        add_action('personal_options_update', array($this, 'save_user_store_fields'));
        add_action('edit_user_profile_update', array($this, 'save_user_store_fields'));
        
        // Add custom capabilities
        add_action('init', array($this, 'add_pos_capabilities'));
        
        // Add settings section to existing settings
        add_filter('addify_mi_general_settings', array($this, 'add_pos_settings_section'));
    }

    /**
     * Add POS submenu to Multi Location Inventory menu.
     */
    public function add_pos_settings_submenu() {
        add_submenu_page(
            'multi-location-inventory',
            __('POS Settings', 'addify-multi-location-inventory'),
            __('POS Settings', 'addify-multi-location-inventory'),
            'manage_woocommerce',
            'mli-pos-settings',
            array($this, 'render_pos_settings_page')
        );
    }

    /**
     * Render POS settings page.
     */
    public function render_pos_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('POS Settings', 'addify-multi-location-inventory'); ?></h1>
            
            <h2><?php esc_html_e('General POS Settings', 'addify-multi-location-inventory'); ?></h2>
            <p><?php esc_html_e('Configure Point of Sale settings for multi-location inventory.', 'addify-multi-location-inventory'); ?></p>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('mli_pos_settings');
                do_settings_sections('mli_pos_settings');
                submit_button();
                ?>
            </form>
            
            <h2><?php esc_html_e('User Store Assignments', 'addify-multi-location-inventory'); ?></h2>
            <p><?php esc_html_e('To assign users to specific stores, edit their user profile and select allowed stores.', 'addify-multi-location-inventory'); ?></p>
            <p><a href="<?php echo admin_url('users.php'); ?>" class="button"><?php esc_html_e('Manage Users', 'addify-multi-location-inventory'); ?></a></p>
            
            <h2><?php esc_html_e('Terminal Management', 'addify-multi-location-inventory'); ?></h2>
            <?php $this->render_terminals_table(); ?>
        </div>
        <?php
    }

    /**
     * Render terminals table.
     */
    private function render_terminals_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_terminals';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            echo '<p>' . esc_html__('No terminals configured yet. Terminals will be created automatically when users log in to POS.', 'addify-multi-location-inventory') . '</p>';
            return;
        }
        
        $terminals = $wpdb->get_results("SELECT t.*, l.name as store_name 
            FROM $table_name t 
            LEFT JOIN {$wpdb->prefix}terms l ON t.store_id = l.term_id 
            WHERE t.status != 'deleted' 
            ORDER BY l.name, t.name");
        
        if (empty($terminals)) {
            echo '<p>' . esc_html__('No terminals found.', 'addify-multi-location-inventory') . '</p>';
            return;
        }
        ?>
        <table class="widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Terminal', 'addify-multi-location-inventory'); ?></th>
                    <th><?php esc_html_e('Store', 'addify-multi-location-inventory'); ?></th>
                    <th><?php esc_html_e('Code', 'addify-multi-location-inventory'); ?></th>
                    <th><?php esc_html_e('Status', 'addify-multi-location-inventory'); ?></th>
                    <th><?php esc_html_e('Created', 'addify-multi-location-inventory'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($terminals as $terminal) : ?>
                    <tr>
                        <td><?php echo esc_html($terminal->name); ?></td>
                        <td><?php echo esc_html($terminal->store_name); ?></td>
                        <td><code><?php echo esc_html($terminal->terminal_code); ?></code></td>
                        <td><?php echo esc_html(ucfirst($terminal->status)); ?></td>
                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($terminal->created_at))); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Add store assignment fields to user profile.
     *
     * @param WP_User $user User object.
     */
    public function add_user_store_fields($user) {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        
        $allowed_stores = get_user_meta($user->ID, 'allowed_stores', true);
        if (!is_array($allowed_stores)) {
            $allowed_stores = array();
        }
        
        // Get all locations
        $locations = get_terms(array(
            'taxonomy' => 'mli_location',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        if (is_wp_error($locations) || empty($locations)) {
            return;
        }
        ?>
        <h3><?php esc_html_e('POS Store Access', 'addify-multi-location-inventory'); ?></h3>
        <table class="form-table">
            <tr>
                <th><label><?php esc_html_e('Allowed Stores', 'addify-multi-location-inventory'); ?></label></th>
                <td>
                    <fieldset>
                        <legend class="screen-reader-text">
                            <span><?php esc_html_e('Allowed Stores', 'addify-multi-location-inventory'); ?></span>
                        </legend>
                        <?php foreach ($locations as $location) : ?>
                            <label>
                                <input type="checkbox" name="allowed_stores[]" value="<?php echo esc_attr($location->term_id); ?>" 
                                    <?php checked(in_array($location->term_id, $allowed_stores)); ?> />
                                <?php echo esc_html($location->name); ?>
                            </label><br />
                        <?php endforeach; ?>
                    </fieldset>
                    <p class="description">
                        <?php esc_html_e('Select which stores this user can access in the POS system. Administrators have access to all stores by default.', 'addify-multi-location-inventory'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th><label><?php esc_html_e('POS Role', 'addify-multi-location-inventory'); ?></label></th>
                <td>
                    <label>
                        <input type="checkbox" name="pos_employee" value="1" 
                            <?php checked(user_can($user, 'pos_employee')); ?> />
                        <?php esc_html_e('Allow POS Access', 'addify-multi-location-inventory'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Enable this to allow the user to log in to the POS system.', 'addify-multi-location-inventory'); ?>
                    </p>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Save user store fields.
     *
     * @param int $user_id User ID.
     */
    public function save_user_store_fields($user_id) {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        
        // Save allowed stores
        if (isset($_POST['allowed_stores'])) {
            $allowed_stores = array_map('intval', $_POST['allowed_stores']);
            update_user_meta($user_id, 'allowed_stores', $allowed_stores);
        } else {
            delete_user_meta($user_id, 'allowed_stores');
        }
        
        // Handle POS employee capability
        $user = new WP_User($user_id);
        if (isset($_POST['pos_employee']) && $_POST['pos_employee'] == '1') {
            $user->add_cap('pos_employee');
        } else {
            $user->remove_cap('pos_employee');
        }
    }

    /**
     * Add POS capabilities to roles.
     */
    public function add_pos_capabilities() {
        // Get administrator role
        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('pos_employee');
            $admin->add_cap('manage_pos_settings');
        }
        
        // Get shop manager role
        $shop_manager = get_role('shop_manager');
        if ($shop_manager) {
            $shop_manager->add_cap('pos_employee');
        }
    }

    /**
     * Add POS section to general settings.
     *
     * @param array $settings Existing settings.
     * @return array Modified settings.
     */
    public function add_pos_settings_section($settings) {
        $pos_settings = array(
            array(
                'name' => __('POS Settings', 'addify-multi-location-inventory'),
                'type' => 'title',
                'desc' => __('Configure Point of Sale integration settings.', 'addify-multi-location-inventory'),
                'id' => 'mli_pos_options',
            ),
            array(
                'name' => __('Enable POS Mode', 'addify-multi-location-inventory'),
                'type' => 'checkbox',
                'desc' => __('Enable Point of Sale functionality for multi-location inventory.', 'addify-multi-location-inventory'),
                'id' => 'mli_enable_pos',
                'default' => 'yes',
            ),
            array(
                'name' => __('Session Timeout (minutes)', 'addify-multi-location-inventory'),
                'type' => 'number',
                'desc' => __('Automatically log out inactive POS sessions after this many minutes.', 'addify-multi-location-inventory'),
                'id' => 'mli_pos_session_timeout',
                'default' => '60',
                'custom_attributes' => array(
                    'min' => '5',
                    'max' => '480',
                    'step' => '5',
                ),
            ),
            array(
                'name' => __('Allow Multiple Terminals', 'addify-multi-location-inventory'),
                'type' => 'checkbox',
                'desc' => __('Allow multiple terminals per store location.', 'addify-multi-location-inventory'),
                'id' => 'mli_pos_multiple_terminals',
                'default' => 'yes',
            ),
            array(
                'type' => 'sectionend',
                'id' => 'mli_pos_options',
            ),
        );
        
        // Insert after general settings
        $insert_position = count($settings) - 1; // Before the last sectionend
        array_splice($settings, $insert_position, 0, $pos_settings);
        
        return $settings;
    }
}

// Initialize the class
new Af_MLI_POS_Settings(); 