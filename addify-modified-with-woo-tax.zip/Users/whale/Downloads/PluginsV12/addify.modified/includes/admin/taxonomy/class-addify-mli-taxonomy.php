<?php
/**
 * Taxonomy Class
 *
 * @package WooCommerce Multi Locations Inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Addify_Mli_Taxonomy' ) ) {
	/**
	 * Taxonomy class
	 */
	class Addify_Mli_Taxonomy {
		
		/**
		 * Global settings
		 *
		 * @var array
		 */
		private $af_mli_global_settings;
		
		/**
		 * Class constructor
		 */
		public function __construct() {
			$this->af_mli_global_settings = get_option( 'af_mli_global_settings' );

			add_action( 'init', array( $this, 'af_register_loc_tax' ), 0 );
			add_action( 'mli_location_add_form_fields', array( $this, 'af_additional_fields_add_new_loc' ), 10, 2 );
			add_action( 'mli_location_edit_form_fields', array( $this, 'af_additional_fields_add_new_loc_edit' ), 10, 2 );
			add_action( 'edited_mli_location', array( $this, 'af_save_fields_tax' ), 10, 2 );  
			add_action( 'create_mli_location', array( $this, 'af_save_fields_tax' ), 10, 2 );
			// Add WooCommerce tax assignment fields
			add_action( 'mli_location_add_form_fields', array( $this, 'af_add_woo_tax_assignment_fields' ), 20, 2 );
			add_action( 'mli_location_edit_form_fields', array( $this, 'af_edit_woo_tax_assignment_fields' ), 20, 2 );
			// Add admin scripts
			add_action( 'admin_enqueue_scripts', array( $this, 'af_enqueue_tax_assignment_scripts' ) );
		}

		/**
		 * Register location taxonomy
		 */
		public function af_register_loc_tax() {
			// ... existing code ...
		}

		/**
		 * Add additional fields
		 */
		public function af_additional_fields_add_new_loc() {
			// ... existing code ...
		}

		/**
		 * Add additional fields edit
		 */
		public function af_additional_fields_add_new_loc_edit( $term ) {
			// ... existing code ...
		}

		/**
		 * Add WooCommerce tax assignment fields for new location
		 */
		public function af_add_woo_tax_assignment_fields() {
			?>
			<div class="form-field term-woo-tax-rates-wrap">
				<label><?php esc_html_e( 'WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?></label>
				<div class="woo-tax-assignment-container">
					<?php $this->render_woo_tax_assignment_ui(); ?>
				</div>
				<p class="description"><?php esc_html_e( 'Assign WooCommerce tax rates that should apply to orders from this location.', 'addify-multi-inventory-management' ); ?></p>
			</div>
			<?php
		}

		/**
		 * Edit WooCommerce tax assignment fields for existing location
		 */
		public function af_edit_woo_tax_assignment_fields( $term ) {
			$assigned_tax_rates = get_term_meta( $term->term_id, 'af_mli_woo_tax_rates', true );
			if ( ! is_array( $assigned_tax_rates ) ) {
				$assigned_tax_rates = array();
			}
			?>
			<tr class="form-field term-woo-tax-rates-wrap">
				<th scope="row">
					<label><?php esc_html_e( 'WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?></label>
				</th>
				<td>
					<div class="woo-tax-assignment-container">
						<?php $this->render_woo_tax_assignment_ui( $assigned_tax_rates ); ?>
					</div>
					<p class="description"><?php esc_html_e( 'Assign WooCommerce tax rates that should apply to orders from this location.', 'addify-multi-inventory-management' ); ?></p>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render WooCommerce tax assignment UI
		 */
		private function render_woo_tax_assignment_ui( $assigned_rates = array() ) {
			global $wpdb;
			
			// Get all WooCommerce tax rates
			$tax_rates = $wpdb->get_results( 
				"SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates 
				ORDER BY tax_rate_order, tax_rate_name" 
			);

			// Group by tax class
			$tax_classes = array();
			$tax_class_labels = array(
				'' => __( 'Standard', 'addify-multi-inventory-management' ),
				'reduced-rate' => __( 'Reduced rate', 'addify-multi-inventory-management' ),
				'zero-rate' => __( 'Zero rate', 'addify-multi-inventory-management' )
			);

			// Get custom tax classes
			$custom_classes = $wpdb->get_results(
				"SELECT * FROM {$wpdb->prefix}wc_tax_rate_classes"
			);
			foreach ( $custom_classes as $class ) {
				$tax_class_labels[ $class->slug ] = $class->name;
			}

			// Group tax rates by class
			foreach ( $tax_rates as $rate ) {
				$class_slug = empty( $rate->tax_rate_class ) ? '' : $rate->tax_rate_class;
				if ( ! isset( $tax_classes[ $class_slug ] ) ) {
					$tax_classes[ $class_slug ] = array();
				}
				$tax_classes[ $class_slug ][] = $rate;
			}

			if ( empty( $tax_rates ) ) {
				?>
				<p><?php 
					printf( 
						esc_html__( 'No tax rates found. Please %s first.', 'addify-multi-inventory-management' ),
						'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=tax' ) . '">' . esc_html__( 'configure tax rates in WooCommerce', 'addify-multi-inventory-management' ) . '</a>'
					); 
				?></p>
				<?php
				return;
			}

			?>
			<style>
				.woo-tax-assignment-container {
					max-width: 600px;
				}
				.tax-class-group {
					margin-bottom: 20px;
					border: 1px solid #ddd;
					padding: 10px;
					background: #f9f9f9;
				}
				.tax-class-title {
					font-weight: bold;
					margin-bottom: 10px;
					display: flex;
					align-items: center;
				}
				.tax-class-title input[type="checkbox"] {
					margin-right: 8px;
				}
				.tax-rate-item {
					margin-left: 25px;
					margin-bottom: 5px;
				}
				.tax-rate-item label {
					display: inline-block;
					font-weight: normal;
				}
				.tax-rate-details {
					color: #666;
					font-size: 12px;
					margin-left: 25px;
				}
			</style>
			<div class="tax-assignment-wrapper">
				<?php foreach ( $tax_classes as $class_slug => $rates ) : 
					$class_label = isset( $tax_class_labels[ $class_slug ] ) ? $tax_class_labels[ $class_slug ] : $class_slug;
				?>
					<div class="tax-class-group">
						<div class="tax-class-title">
							<input type="checkbox" 
								class="select-all-class" 
								data-class="<?php echo esc_attr( $class_slug ); ?>"
							/>
							<?php echo esc_html( $class_label ); ?> <?php esc_html_e( 'Rates', 'addify-multi-inventory-management' ); ?>
						</div>
						<?php foreach ( $rates as $rate ) : 
							$is_checked = in_array( $rate->tax_rate_id, $assigned_rates );
							$location_info = array();
							if ( ! empty( $rate->tax_rate_country ) ) {
								$location_info[] = $rate->tax_rate_country;
							}
							if ( ! empty( $rate->tax_rate_state ) ) {
								$location_info[] = $rate->tax_rate_state;
							}
						?>
							<div class="tax-rate-item">
								<label>
									<input type="checkbox" 
										name="af_mli_woo_tax_rates[]" 
										value="<?php echo esc_attr( $rate->tax_rate_id ); ?>"
										data-class="<?php echo esc_attr( $class_slug ); ?>"
										<?php checked( $is_checked ); ?>
									/>
									<?php echo esc_html( $rate->tax_rate_name ); ?> 
									(<?php echo esc_html( $rate->tax_rate ); ?>%)
								</label>
								<?php if ( ! empty( $location_info ) ) : ?>
									<div class="tax-rate-details">
										<?php echo esc_html( implode( ', ', $location_info ) ); ?>
										<?php if ( $rate->tax_rate_compound ) : ?>
											| <?php esc_html_e( 'Compound', 'addify-multi-inventory-management' ); ?>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>
			</div>
			<p style="margin-top: 15px;">
				<a href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=tax' ); ?>" target="_blank">
					<?php esc_html_e( 'Manage WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?>
				</a>
			</p>
			<?php
		}

		/**
		 * Enqueue tax assignment scripts
		 */
		public function af_enqueue_tax_assignment_scripts( $hook ) {
			if ( 'edit-tags.php' !== $hook && 'term.php' !== $hook ) {
				return;
			}
			
			if ( ! isset( $_GET['taxonomy'] ) || 'mli_location' !== $_GET['taxonomy'] ) {
				return;
			}

			?>
			<script type="text/javascript">
			jQuery(document).ready(function($) {
				// Handle select all checkbox
				$('.select-all-class').on('change', function() {
					var classSlug = $(this).data('class');
					var isChecked = $(this).prop('checked');
					$('input[data-class="' + classSlug + '"]').prop('checked', isChecked);
				});

				// Update select all state when individual checkboxes change
				$('input[name="af_mli_woo_tax_rates[]"]').on('change', function() {
					var classSlug = $(this).data('class');
					var allChecked = true;
					$('input[name="af_mli_woo_tax_rates[]"][data-class="' + classSlug + '"]').each(function() {
						if (!$(this).prop('checked')) {
							allChecked = false;
							return false;
						}
					});
					$('.select-all-class[data-class="' + classSlug + '"]').prop('checked', allChecked);
				});

				// Initialize select all checkboxes state
				$('.select-all-class').each(function() {
					var classSlug = $(this).data('class');
					var allChecked = true;
					$('input[name="af_mli_woo_tax_rates[]"][data-class="' + classSlug + '"]').each(function() {
						if (!$(this).prop('checked')) {
							allChecked = false;
							return false;
						}
					});
					$(this).prop('checked', allChecked);
				});
			});
			</script>
			<?php
		}

		/**
		 * Save taxonomy fields
		 * 
		 * @param int $term_id Term ID
		 * @param int $tt_id Term taxonomy ID
		 */
		public function af_save_fields_tax( $term_id, $tt_id = 0 ) {
			// ... existing code ...

			// Save WooCommerce tax rate assignments
			if ( isset( $_POST['af_mli_woo_tax_rates'] ) && is_array( $_POST['af_mli_woo_tax_rates'] ) ) {
				$tax_rates = array_map( 'intval', $_POST['af_mli_woo_tax_rates'] );
				update_term_meta( $term_id, 'af_mli_woo_tax_rates', $tax_rates );
			} else {
				// Only clear if form was submitted (nonce check)
				if ( isset( $_POST['loc_taxonomy_nonce_field'] ) ) {
					update_term_meta( $term_id, 'af_mli_woo_tax_rates', array() );
				}
			}
		}
	}

	new Addify_Mli_Taxonomy();
}