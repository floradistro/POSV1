<?php
/**
 * WooCommerce Tax Integration for Addify Multi Location Inventory
 *
 * @package Addify Multi Location Inventory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Addify_MLI_Woo_Tax_Integration' ) ) {
	/**
	 * WooCommerce Tax Integration class
	 */
	class Addify_MLI_Woo_Tax_Integration {
		
		/**
		 * Constructor
		 */
		public function __construct() {
			// Add tax assignment fields to location taxonomy
			add_action( 'mli_location_add_form_fields', array( $this, 'add_tax_assignment_fields' ), 20 );
			add_action( 'mli_location_edit_form_fields', array( $this, 'edit_tax_assignment_fields' ), 20 );
			
			// Save tax assignments
			add_action( 'edited_mli_location', array( $this, 'save_tax_assignments' ), 20, 2 );
			add_action( 'create_mli_location', array( $this, 'save_tax_assignments' ), 20, 2 );
			
			// Add admin scripts
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}
		
		/**
		 * Add tax assignment fields for new location
		 */
		public function add_tax_assignment_fields() {
			?>
			<div class="form-field term-woo-tax-rates-wrap">
				<label><?php esc_html_e( 'WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?></label>
				<div class="woo-tax-assignment-container">
					<?php $this->render_tax_assignment_ui(); ?>
				</div>
				<p class="description"><?php esc_html_e( 'Assign WooCommerce tax rates that should apply to orders from this location.', 'addify-multi-inventory-management' ); ?></p>
			</div>
			<?php
		}
		
		/**
		 * Edit tax assignment fields for existing location
		 */
		public function edit_tax_assignment_fields( $term ) {
			$assigned_tax_rates = get_term_meta( $term->term_id, 'af_mli_woo_tax_rates', true );
			if ( ! is_array( $assigned_tax_rates ) ) {
				$assigned_tax_rates = array();
			}
			?>
			<tr class="form-field term-woo-tax-rates-wrap">
				<th scope="row">
					<label><?php esc_html_e( 'WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?></label>
				</th>
				<td>
					<div class="woo-tax-assignment-container">
						<?php $this->render_tax_assignment_ui( $assigned_tax_rates ); ?>
					</div>
					<p class="description"><?php esc_html_e( 'Assign WooCommerce tax rates that should apply to orders from this location.', 'addify-multi-inventory-management' ); ?></p>
				</td>
			</tr>
			<?php
		}
		
		/**
		 * Render tax assignment UI
		 */
		private function render_tax_assignment_ui( $assigned_rates = array() ) {
			global $wpdb;
			
			// Get all WooCommerce tax rates
			$tax_rates = $wpdb->get_results( 
				"SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates 
				ORDER BY tax_rate_order, tax_rate_name" 
			);
			
			// Group by tax class
			$tax_classes = array();
			$tax_class_labels = array(
				'' => __( 'Standard', 'addify-multi-inventory-management' ),
				'reduced-rate' => __( 'Reduced rate', 'addify-multi-inventory-management' ),
				'zero-rate' => __( 'Zero rate', 'addify-multi-inventory-management' )
			);
			
			// Get custom tax classes
			$custom_classes = $wpdb->get_results(
				"SELECT * FROM {$wpdb->prefix}wc_tax_rate_classes"
			);
			foreach ( $custom_classes as $class ) {
				$tax_class_labels[ $class->slug ] = $class->name;
			}
			
			// Group tax rates by class
			foreach ( $tax_rates as $rate ) {
				$class_slug = empty( $rate->tax_rate_class ) ? '' : $rate->tax_rate_class;
				if ( ! isset( $tax_classes[ $class_slug ] ) ) {
					$tax_classes[ $class_slug ] = array();
				}
				$tax_classes[ $class_slug ][] = $rate;
			}
			
			if ( empty( $tax_rates ) ) {
				?>
				<p><?php 
					printf( 
						esc_html__( 'No tax rates found. Please %s first.', 'addify-multi-inventory-management' ),
						'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=tax' ) . '">' . esc_html__( 'configure tax rates in WooCommerce', 'addify-multi-inventory-management' ) . '</a>'
					); 
				?></p>
				<?php
				return;
			}
			
			?>
			<style>
				.woo-tax-assignment-container {
					max-width: 600px;
				}
				.tax-class-group {
					margin-bottom: 20px;
					border: 1px solid #ddd;
					padding: 10px;
					background: #f9f9f9;
				}
				.tax-class-title {
					font-weight: bold;
					margin-bottom: 10px;
					display: flex;
					align-items: center;
				}
				.tax-class-title input[type="checkbox"] {
					margin-right: 8px;
				}
				.tax-rate-item {
					margin-left: 25px;
					margin-bottom: 5px;
				}
				.tax-rate-item label {
					display: inline-block;
					font-weight: normal;
				}
				.tax-rate-details {
					color: #666;
					font-size: 12px;
					margin-left: 25px;
				}
			</style>
			<div class="tax-assignment-wrapper">
				<?php foreach ( $tax_classes as $class_slug => $rates ) : 
					$class_label = isset( $tax_class_labels[ $class_slug ] ) ? $tax_class_labels[ $class_slug ] : $class_slug;
				?>
					<div class="tax-class-group">
						<div class="tax-class-title">
							<input type="checkbox" 
								class="select-all-class" 
								data-class="<?php echo esc_attr( $class_slug ); ?>"
							/>
							<?php echo esc_html( $class_label ); ?> <?php esc_html_e( 'Rates', 'addify-multi-inventory-management' ); ?>
						</div>
						<?php foreach ( $rates as $rate ) : 
							$is_checked = in_array( $rate->tax_rate_id, $assigned_rates );
							$location_info = array();
							if ( ! empty( $rate->tax_rate_country ) ) {
								$location_info[] = $rate->tax_rate_country;
							}
							if ( ! empty( $rate->tax_rate_state ) ) {
								$location_info[] = $rate->tax_rate_state;
							}
						?>
							<div class="tax-rate-item">
								<label>
									<input type="checkbox" 
										name="af_mli_woo_tax_rates[]" 
										value="<?php echo esc_attr( $rate->tax_rate_id ); ?>"
										data-class="<?php echo esc_attr( $class_slug ); ?>"
										<?php checked( $is_checked ); ?>
									/>
									<?php echo esc_html( $rate->tax_rate_name ); ?> 
									(<?php echo esc_html( $rate->tax_rate ); ?>%)
								</label>
								<?php if ( ! empty( $location_info ) ) : ?>
									<div class="tax-rate-details">
										<?php echo esc_html( implode( ', ', $location_info ) ); ?>
										<?php if ( $rate->tax_rate_compound ) : ?>
											| <?php esc_html_e( 'Compound', 'addify-multi-inventory-management' ); ?>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>
			</div>
			<p style="margin-top: 15px;">
				<a href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=tax' ); ?>" target="_blank">
					<?php esc_html_e( 'Manage WooCommerce Tax Rates', 'addify-multi-inventory-management' ); ?>
				</a>
			</p>
			<?php
		}
		
		/**
		 * Enqueue scripts
		 */
		public function enqueue_scripts( $hook ) {
			if ( 'edit-tags.php' !== $hook && 'term.php' !== $hook ) {
				return;
			}
			
			if ( ! isset( $_GET['taxonomy'] ) || 'mli_location' !== $_GET['taxonomy'] ) {
				return;
			}
			
			?>
			<script type="text/javascript">
			jQuery(document).ready(function($) {
				// Handle select all checkbox
				$('.select-all-class').on('change', function() {
					var classSlug = $(this).data('class');
					var isChecked = $(this).prop('checked');
					$('input[data-class="' + classSlug + '"]').prop('checked', isChecked);
				});
				
				// Update select all state when individual checkboxes change
				$('input[name="af_mli_woo_tax_rates[]"]').on('change', function() {
					var classSlug = $(this).data('class');
					var allChecked = true;
					$('input[name="af_mli_woo_tax_rates[]"][data-class="' + classSlug + '"]').each(function() {
						if (!$(this).prop('checked')) {
							allChecked = false;
							return false;
						}
					});
					$('.select-all-class[data-class="' + classSlug + '"]').prop('checked', allChecked);
				});
				
				// Initialize select all checkboxes state
				$('.select-all-class').each(function() {
					var classSlug = $(this).data('class');
					var allChecked = true;
					$('input[name="af_mli_woo_tax_rates[]"][data-class="' + classSlug + '"]').each(function() {
						if (!$(this).prop('checked')) {
							allChecked = false;
							return false;
						}
					});
					$(this).prop('checked', allChecked);
				});
			});
			</script>
			<?php
		}
		
		/**
		 * Save tax assignments
		 */
		public function save_tax_assignments( $term_id, $tt_id = '' ) {
			// Check nonce
			if ( ! isset( $_POST['loc_taxonomy_nonce_field'] ) || 
				! wp_verify_nonce( $_POST['loc_taxonomy_nonce_field'], 'loc_taxonomy_nonce' ) ) {
				return;
			}
			
			// Save WooCommerce tax rate assignments
			if ( isset( $_POST['af_mli_woo_tax_rates'] ) && is_array( $_POST['af_mli_woo_tax_rates'] ) ) {
				$tax_rates = array_map( 'intval', $_POST['af_mli_woo_tax_rates'] );
				update_term_meta( $term_id, 'af_mli_woo_tax_rates', $tax_rates );
			} else {
				// Only clear if form was submitted
				update_term_meta( $term_id, 'af_mli_woo_tax_rates', array() );
			}
		}
		
		/**
		 * Get WooCommerce tax rates for a location
		 * 
		 * @param int $location_id Location term ID
		 * @return array Tax rates data
		 */
		public static function get_location_tax_rates( $location_id ) {
			global $wpdb;
			
			// Get assigned tax rate IDs
			$assigned_rates = get_term_meta( $location_id, 'af_mli_woo_tax_rates', true );
			if ( ! is_array( $assigned_rates ) || empty( $assigned_rates ) ) {
				return array(
					'tax_rates' => array(),
					'total_rate' => 0
				);
			}
			
			// Get tax rate details from WooCommerce
			$placeholders = array_fill( 0, count( $assigned_rates ), '%d' );
			$query = $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates 
				WHERE tax_rate_id IN (" . implode( ',', $placeholders ) . ")
				ORDER BY tax_rate_order, tax_rate_name",
				$assigned_rates
			);
			
			$tax_rates = $wpdb->get_results( $query );
			
			// Format the response
			$formatted_rates = array();
			$total_rate = 0;
			
			foreach ( $tax_rates as $rate ) {
				$formatted_rate = array(
					'id' => $rate->tax_rate_id,
					'name' => $rate->tax_rate_name,
					'rate' => floatval( $rate->tax_rate ),
					'compound' => $rate->tax_rate_compound ? 'yes' : 'no',
					'shipping' => $rate->tax_rate_shipping ? 'yes' : 'no',
					'class' => $rate->tax_rate_class
				);
				
				$formatted_rates[] = $formatted_rate;
				
				// Calculate total rate (simple addition, actual calculation should consider compound taxes)
				if ( ! $rate->tax_rate_compound ) {
					$total_rate += floatval( $rate->tax_rate );
				}
			}
			
			// Add compound taxes to total
			foreach ( $tax_rates as $rate ) {
				if ( $rate->tax_rate_compound ) {
					$total_rate = $total_rate + ( floatval( $rate->tax_rate ) * ( 1 + $total_rate / 100 ) );
				}
			}
			
			return array(
				'tax_rates' => $formatted_rates,
				'total_rate' => round( $total_rate, 3 )
			);
		}
	}
	
	// Initialize the integration
	new Addify_MLI_Woo_Tax_Integration();
} 