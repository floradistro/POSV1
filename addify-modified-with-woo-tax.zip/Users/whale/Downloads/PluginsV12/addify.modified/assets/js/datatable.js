
// jQuery( document ).ready(
	
// 	function($){

// 		$('.af_mli_products_table').DataTable({
  
// 	        "searching": true,  // Enable searching
	  
// 	        "paging": false,    // Disable pagination
	  
// 	        "ordering": false,  // Disable sorting
	  
// 	        "info": false       // Disable information display
	  
// 	    });
// 	}
// );