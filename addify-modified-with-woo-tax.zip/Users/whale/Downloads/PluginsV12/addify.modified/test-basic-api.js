#!/usr/bin/env node

const WORDPRESS_URL = 'http://api.floradistro.com';

console.log('🔍 Testing Basic WordPress API:', WORDPRESS_URL);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// Test 1: Basic WordPress REST API
async function testWordPressAPI() {
  console.log('📝 Test 1: Testing WordPress REST API...');
  try {
    const response = await fetch(`${WORDPRESS_URL}/wp-json/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log(`   ✅ WordPress REST API is active`);
      console.log(`   Site Name: ${data.name || 'Unknown'}`);
      console.log(`   Site URL: ${data.url || 'Unknown'}`);
      
      // Check for namespaces
      if (data.namespaces) {
        console.log(`   Available namespaces: ${data.namespaces.join(', ')}`);
        
        // Check for our custom namespaces
        const hasAddify = data.namespaces.includes('addify-mli/v1');
        const hasWcPos = data.namespaces.includes('wc-pos/v1');
        const hasFloraRewards = data.namespaces.includes('flora-rewards/v1');
        
        console.log(`\n   Plugin Status:`);
        console.log(`   - Addify MLI namespace: ${hasAddify ? '✅ Found' : '❌ Not found'}`);
        console.log(`   - WC POS namespace: ${hasWcPos ? '✅ Found' : '❌ Not found'}`);
        console.log(`   - Flora Rewards namespace: ${hasFloraRewards ? '✅ Found' : '❌ Not found'}`);
      }
    } else {
      const error = await response.text();
      console.log(`   ❌ Error: ${error}`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test 2: Check plugin status via system info (if accessible)
async function testPluginStatus() {
  console.log('🔌 Test 2: Checking installed plugins...');
  try {
    // Try to get plugin list (this might require authentication)
    const response = await fetch(`${WORDPRESS_URL}/wp-json/wp/v2/plugins`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    console.log(`   Status: ${response.status} ${response.statusText}`);
    
    if (response.status === 401) {
      console.log(`   ℹ️  Plugin list requires authentication (expected)`);
    } else if (response.ok) {
      const plugins = await response.json();
      console.log(`   Found ${plugins.length} plugins`);
    }
  } catch (error) {
    console.log(`   ❌ Network error: ${error.message}`);
  }
  console.log('');
}

// Test 3: Check for existing Addify endpoints (from existing plugin)
async function testExistingAddifyEndpoints() {
  console.log('📦 Test 3: Checking existing Addify endpoints...');
  
  const endpoints = [
    '/wp-json/wc/v3/addify_headless_inventory',
    '/wp-json/afacr' // Old namespace from server.php
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      console.log(`   ${endpoint}: ${response.status} ${response.statusText}`);
    } catch (error) {
      console.log(`   ${endpoint}: ❌ Network error`);
    }
  }
  console.log('');
}

// Test 4: Direct PHP file access (to check if plugin is in the right place)
async function testDirectAccess() {
  console.log('🔍 Test 4: Checking direct plugin file access...');
  
  const files = [
    '/wp-content/plugins/addify-multi-inventory-management/class-addify-multi-inventory-management.php',
    '/wp-content/plugins/flora-points-rewards-headless/flora-points-rewards-headless.php'
  ];

  for (const file of files) {
    try {
      const response = await fetch(`${WORDPRESS_URL}${file}`, {
        method: 'HEAD'
      });

      // PHP files should not be directly accessible (403 or 404 is expected)
      if (response.status === 403 || response.status === 404) {
        console.log(`   ${file}: ✅ Protected (${response.status})`);
      } else {
        console.log(`   ${file}: ⚠️  Status ${response.status}`);
      }
    } catch (error) {
      console.log(`   ${file}: ❌ Network error`);
    }
  }
  console.log('');
}

// Run all tests
async function runAllTests() {
  await testWordPressAPI();
  await testPluginStatus();
  await testExistingAddifyEndpoints();
  await testDirectAccess();
  
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📋 Summary:');
  console.log('\nIf the custom namespaces are not showing:');
  console.log('1. Ensure both plugins are activated in WordPress admin');
  console.log('2. Check that REST API is enabled (Settings > Permalinks > Save)');
  console.log('3. Clear any caching plugins');
  console.log('4. Check PHP error logs for any issues');
  console.log('\nPlugin folder names should be:');
  console.log('- /wp-content/plugins/addify-multi-inventory-management/');
  console.log('- /wp-content/plugins/flora-points-rewards-headless/');
}

// Execute tests
runAllTests().catch(console.error); 