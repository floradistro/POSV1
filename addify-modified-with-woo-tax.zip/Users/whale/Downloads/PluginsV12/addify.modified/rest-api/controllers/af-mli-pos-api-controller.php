<?php
/**
 * Addify Multi Inventory POS REST API Controller
 * 
 * Provides REST API endpoints for POS functionality including authentication,
 * terminal management, and store access control.
 *
 * @package Addify\RestApi
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * POS Multi Inventory REST API controller class.
 *
 * @package Addify\RestApi
 * @extends WC_REST_CRUD_Controller
 */
class Af_MLI_POS_Api_Controller extends WC_REST_CRUD_Controller {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'addify-mli/v1';

    /**
     * Route base.
     *
     * @var string
     */
    protected $rest_base = 'pos';

    /**
     * Location taxonomy type.
     *
     * @var string
     */
    protected $location_taxonomy = 'mli_location';

    /**
     * Constructor.
     */
    public function __construct() {
        // Nothing needed here
    }

    /**
     * Register all REST API routes.
     */
    public function register_routes() {
        // Authentication endpoints
        register_rest_route(
            $this->namespace,
            '/auth/login',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'authenticate_user'),
                    'permission_callback' => '__return_true',
                    'args'                => $this->get_auth_args(),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/auth/validate',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'validate_token'),
                    'permission_callback' => array($this, 'check_auth_permissions'),
                ),
            )
        );

        // Public stores endpoint (for login dropdown)
        register_rest_route(
            $this->namespace,
            '/stores/public',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_public_stores'),
                    'permission_callback' => '__return_true',
                ),
            )
        );

        // Terminal management endpoints
        register_rest_route(
            $this->namespace,
            '/terminals/(?P<store_id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_store_terminals'),
                    'permission_callback' => array($this, 'check_store_access_permissions'),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'create_terminal'),
                    'permission_callback' => array($this, 'check_store_manage_permissions'),
                    'args'                => $this->get_terminal_args(),
                ),
            )
        );

        // Session management
        register_rest_route(
            $this->namespace,
            '/session',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_current_session'),
                    'permission_callback' => array($this, 'check_auth_permissions'),
                ),
                array(
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => array($this, 'end_session'),
                    'permission_callback' => array($this, 'check_auth_permissions'),
                ),
            )
        );

        // Store access validation
        register_rest_route(
            $this->namespace,
            '/stores/(?P<id>[\d]+)/validate-access',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'validate_store_access'),
                    'permission_callback' => array($this, 'check_auth_permissions'),
                ),
            )
        );
    }

    /**
     * Authenticate WordPress user for POS access.
     * 
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function authenticate_user($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $store_id = absint($request->get_param('store_id'));
        $terminal_id = sanitize_text_field($request->get_param('terminal_id'));

        // Authenticate WordPress user
        $user = wp_authenticate($email, $password);

        if (is_wp_error($user)) {
            return new WP_Error(
                'auth_failed',
                __('Invalid email or password.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        // Check if user has POS access capability
        if (!user_can($user, 'manage_woocommerce') && !user_can($user, 'pos_employee')) {
            return new WP_Error(
                'insufficient_permissions',
                __('User does not have POS access.', 'addify-multi-location-inventory'),
                array('status' => 403)
            );
        }

        // Check if user has access to the specified store
        $allowed_stores = $this->get_user_allowed_stores($user->ID);
        if (!in_array($store_id, $allowed_stores)) {
            return new WP_Error(
                'store_access_denied',
                __('User does not have access to this store.', 'addify-multi-location-inventory'),
                array('status' => 403)
            );
        }

        // Generate JWT token or session
        $token = $this->generate_auth_token($user->ID, $store_id, $terminal_id);

        // Create session record
        $this->create_pos_session($user->ID, $store_id, $terminal_id, $token);

        // Get store details
        $store_term = get_term($store_id, $this->location_taxonomy);

        return new WP_REST_Response(
            array(
                'success' => true,
                'token' => $token,
                'user' => array(
                    'id' => $user->ID,
                    'email' => $user->user_email,
                    'display_name' => $user->display_name,
                    'capabilities' => array_keys($user->caps),
                ),
                'store' => array(
                    'id' => $store_id,
                    'name' => $store_term ? $store_term->name : '',
                    'slug' => $store_term ? $store_term->slug : '',
                ),
                'terminal' => array(
                    'id' => $terminal_id,
                ),
                'allowed_stores' => $allowed_stores,
            ),
            200
        );
    }

    /**
     * Get public store list for login.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_public_stores($request) {
        $locations = get_terms(array(
            'taxonomy' => $this->location_taxonomy,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));

        if (is_wp_error($locations)) {
            return $locations;
        }

        $stores = array();
        foreach ($locations as $location) {
            // Check if location is active/enabled
            $is_active = get_term_meta($location->term_id, 'mli_location_status', true);
            if ($is_active !== 'inactive') {
                $stores[] = array(
                    'id' => $location->term_id,
                    'name' => $location->name,
                    'slug' => $location->slug,
                    'description' => $location->description,
                );
            }
        }

        return new WP_REST_Response($stores, 200);
    }

    /**
     * Get terminals for a specific store.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_store_terminals($request) {
        $store_id = absint($request->get_param('store_id'));
        
        // Get terminals from database
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_terminals';
        
        // Check if table exists, if not return empty array
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            // Return default terminals if table doesn't exist yet
            return new WP_REST_Response(
                array(
                    array(
                        'id' => 'terminal-1',
                        'name' => 'Terminal 1',
                        'store_id' => $store_id,
                        'status' => 'available',
                    ),
                    array(
                        'id' => 'terminal-2',
                        'name' => 'Terminal 2',
                        'store_id' => $store_id,
                        'status' => 'available',
                    ),
                ),
                200
            );
        }

        $terminals = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE store_id = %d AND status != 'deleted'",
                $store_id
            ),
            ARRAY_A
        );

        // Add session info if terminal is in use
        foreach ($terminals as &$terminal) {
            $session = $this->get_active_terminal_session($terminal['id']);
            if ($session) {
                $terminal['current_user'] = array(
                    'id' => $session->user_id,
                    'name' => get_userdata($session->user_id)->display_name,
                );
                $terminal['status'] = 'in_use';
            }
        }

        return new WP_REST_Response($terminals, 200);
    }

    /**
     * Validate current authentication token.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function validate_token($request) {
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            return new WP_Error(
                'invalid_token',
                __('Invalid or expired token.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        $user = get_userdata($user_id);
        $session = $this->get_user_active_session($user_id);

        if (!$session) {
            return new WP_Error(
                'no_active_session',
                __('No active POS session found.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        return new WP_REST_Response(
            array(
                'valid' => true,
                'user' => array(
                    'id' => $user->ID,
                    'email' => $user->user_email,
                    'display_name' => $user->display_name,
                ),
                'session' => $session,
            ),
            200
        );
    }

    /**
     * Validate user access to a specific store.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function validate_store_access($request) {
        $store_id = absint($request->get_param('id'));
        $user_id = get_current_user_id();

        if (!$user_id) {
            return new WP_Error(
                'not_authenticated',
                __('User not authenticated.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        $allowed_stores = $this->get_user_allowed_stores($user_id);
        $has_access = in_array($store_id, $allowed_stores);

        return new WP_REST_Response(
            array(
                'has_access' => $has_access,
                'store_id' => $store_id,
                'user_id' => $user_id,
            ),
            200
        );
    }

    /**
     * Get current POS session details.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function get_current_session($request) {
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            return new WP_Error(
                'not_authenticated',
                __('User not authenticated.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        $session = $this->get_user_active_session($user_id);

        if (!$session) {
            return new WP_Error(
                'no_session',
                __('No active session found.', 'addify-multi-location-inventory'),
                array('status' => 404)
            );
        }

        return new WP_REST_Response($session, 200);
    }

    /**
     * End current POS session.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function end_session($request) {
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            return new WP_Error(
                'not_authenticated',
                __('User not authenticated.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        // End the session in database
        $this->end_user_session($user_id);

        return new WP_REST_Response(
            array(
                'success' => true,
                'message' => __('Session ended successfully.', 'addify-multi-location-inventory'),
            ),
            200
        );
    }

    /**
     * Create a new terminal.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
     */
    public function create_terminal($request) {
        $store_id = absint($request->get_param('store_id'));
        $name = sanitize_text_field($request->get_param('name'));
        $terminal_code = sanitize_text_field($request->get_param('terminal_code'));

        // Validate store exists
        $store = get_term($store_id, $this->location_taxonomy);
        if (!$store || is_wp_error($store)) {
            return new WP_Error(
                'invalid_store',
                __('Invalid store ID.', 'addify-multi-location-inventory'),
                array('status' => 400)
            );
        }

        // Create terminal in database
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_terminals';

        // Create table if it doesn't exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $this->create_terminals_table();
        }

        $result = $wpdb->insert(
            $table_name,
            array(
                'store_id' => $store_id,
                'terminal_code' => $terminal_code ?: uniqid('terminal-'),
                'name' => $name,
                'status' => 'available',
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );

        if ($result === false) {
            return new WP_Error(
                'db_error',
                __('Failed to create terminal.', 'addify-multi-location-inventory'),
                array('status' => 500)
            );
        }

        $terminal_id = $wpdb->insert_id;

        return new WP_REST_Response(
            array(
                'id' => $terminal_id,
                'store_id' => $store_id,
                'terminal_code' => $terminal_code,
                'name' => $name,
                'status' => 'available',
            ),
            201
        );
    }

    /**
     * Get authentication arguments.
     *
     * @return array
     */
    protected function get_auth_args() {
        return array(
            'email' => array(
                'description' => __('User email address.', 'addify-multi-location-inventory'),
                'type' => 'string',
                'format' => 'email',
                'required' => true,
            ),
            'password' => array(
                'description' => __('User password.', 'addify-multi-location-inventory'),
                'type' => 'string',
                'required' => true,
            ),
            'store_id' => array(
                'description' => __('Store/Location ID.', 'addify-multi-location-inventory'),
                'type' => 'integer',
                'required' => true,
            ),
            'terminal_id' => array(
                'description' => __('Terminal ID.', 'addify-multi-location-inventory'),
                'type' => 'string',
                'required' => true,
            ),
        );
    }

    /**
     * Get terminal arguments.
     *
     * @return array
     */
    protected function get_terminal_args() {
        return array(
            'name' => array(
                'description' => __('Terminal name.', 'addify-multi-location-inventory'),
                'type' => 'string',
                'required' => true,
            ),
            'terminal_code' => array(
                'description' => __('Unique terminal code.', 'addify-multi-location-inventory'),
                'type' => 'string',
                'required' => false,
            ),
        );
    }

    /**
     * Generate authentication token.
     *
     * @param int $user_id User ID.
     * @param int $store_id Store ID.
     * @param string $terminal_id Terminal ID.
     * @return string
     */
    protected function generate_auth_token($user_id, $store_id, $terminal_id) {
        // For now, use WordPress nonce system
        // In production, implement JWT or similar
        $data = $user_id . ':' . $store_id . ':' . $terminal_id . ':' . time();
        return wp_hash($data);
    }

    /**
     * Get user's allowed stores.
     *
     * @param int $user_id User ID.
     * @return array
     */
    protected function get_user_allowed_stores($user_id) {
        // Check if user is admin
        if (user_can($user_id, 'manage_options')) {
            // Admins have access to all stores
            $terms = get_terms(array(
                'taxonomy' => $this->location_taxonomy,
                'hide_empty' => false,
                'fields' => 'ids',
            ));
            return is_wp_error($terms) ? array() : $terms;
        }

        // Get user's allowed stores from user meta
        $allowed_stores = get_user_meta($user_id, 'allowed_stores', true);
        
        if (!is_array($allowed_stores)) {
            $allowed_stores = array();
        }

        return array_map('intval', $allowed_stores);
    }

    /**
     * Create POS session.
     *
     * @param int $user_id User ID.
     * @param int $store_id Store ID.
     * @param string $terminal_id Terminal ID.
     * @param string $token Session token.
     * @return bool
     */
    protected function create_pos_session($user_id, $store_id, $terminal_id, $token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_pos_sessions';

        // Create table if it doesn't exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $this->create_sessions_table();
        }

        // End any existing sessions for this user
        $wpdb->update(
            $table_name,
            array('status' => 'ended', 'ended_at' => current_time('mysql')),
            array('user_id' => $user_id, 'status' => 'active'),
            array('%s', '%s'),
            array('%d', '%s')
        );

        // Create new session
        return $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'store_id' => $store_id,
                'terminal_id' => $terminal_id,
                'token' => $token,
                'status' => 'active',
                'started_at' => current_time('mysql'),
                'last_activity' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Get user's active session.
     *
     * @param int $user_id User ID.
     * @return object|null
     */
    protected function get_user_active_session($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_pos_sessions';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            return null;
        }

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = %d AND status = 'active' ORDER BY started_at DESC LIMIT 1",
                $user_id
            )
        );
    }

    /**
     * Get active session for a terminal.
     *
     * @param string $terminal_id Terminal ID.
     * @return object|null
     */
    protected function get_active_terminal_session($terminal_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_pos_sessions';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            return null;
        }

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE terminal_id = %s AND status = 'active' ORDER BY started_at DESC LIMIT 1",
                $terminal_id
            )
        );
    }

    /**
     * End user's session.
     *
     * @param int $user_id User ID.
     * @return bool
     */
    protected function end_user_session($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_pos_sessions';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            return false;
        }

        return $wpdb->update(
            $table_name,
            array('status' => 'ended', 'ended_at' => current_time('mysql')),
            array('user_id' => $user_id, 'status' => 'active'),
            array('%s', '%s'),
            array('%d', '%s')
        );
    }

    /**
     * Create terminals table.
     */
    protected function create_terminals_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_terminals';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            store_id int(11) NOT NULL,
            terminal_code varchar(50) NOT NULL,
            name varchar(100) NOT NULL,
            status varchar(20) DEFAULT 'available',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY terminal_code (terminal_code),
            KEY store_id (store_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Create sessions table.
     */
    protected function create_sessions_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'af_mli_pos_sessions';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            user_id int(11) NOT NULL,
            store_id int(11) NOT NULL,
            terminal_id varchar(50) NOT NULL,
            token varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'active',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            ended_at datetime DEFAULT NULL,
            last_activity datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY store_id (store_id),
            KEY terminal_id (terminal_id),
            KEY status (status)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Check if user has permission to access authenticated endpoints.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return bool|WP_Error
     */
    public function check_auth_permissions($request) {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return new WP_Error(
                'rest_forbidden',
                __('You must be logged in to access this endpoint.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        return true;
    }

    /**
     * Check if user has permission to access store data.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return bool|WP_Error
     */
    public function check_store_access_permissions($request) {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'rest_forbidden',
                __('You must be logged in to access this endpoint.', 'addify-multi-location-inventory'),
                array('status' => 401)
            );
        }

        $store_id = absint($request->get_param('store_id'));
        $user_id = get_current_user_id();
        $allowed_stores = $this->get_user_allowed_stores($user_id);

        if (!in_array($store_id, $allowed_stores)) {
            return new WP_Error(
                'rest_forbidden',
                __('You do not have access to this store.', 'addify-multi-location-inventory'),
                array('status' => 403)
            );
        }

        return true;
    }

    /**
     * Check if user has permission to manage store.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return bool|WP_Error
     */
    public function check_store_manage_permissions($request) {
        if (!current_user_can('manage_woocommerce')) {
            return new WP_Error(
                'rest_forbidden',
                __('You do not have permission to manage stores.', 'addify-multi-location-inventory'),
                array('status' => 403)
            );
        }

        return true;
    }
} 