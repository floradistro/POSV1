<?php
/**
 * Addify Multi Inventory Headless REST API Controller
 * 
 * Provides comprehensive REST API endpoints for headless inventory management
 * without affecting existing plugin functionality.
 *
 * @package Addify\RestApi
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Headless Multi Inventory REST API controller class.
 *
 * @package Addify\RestApi
 * @extends WC_REST_CRUD_Controller
 */
class Af_MLI_Headless_Api_Controller extends WC_REST_CRUD_Controller {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'wc/v3';

    /**
     * Route base.
     *
     * @var string
     */
    protected $rest_base = 'addify_headless_inventory';

    /**
     * Location taxonomy type.
     *
     * @var string
     */
    protected $location_taxonomy = 'mli_location';

    /**
     * Inventory post type.
     *
     * @var string
     */
    protected $inventory_post_type = 'af_prod_lvl_invent';

    /**
     * Constructor.
     */
    public function __construct() {
        // Nothing needed here
    }

    /**
     * Register all REST API routes.
     */
    public function register_routes() {
        // Locations endpoints
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/locations',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_locations'),
                    'permission_callback' => array($this, 'get_items_permissions_check'),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'create_location'),
                    'permission_callback' => array($this, 'create_item_permissions_check'),
                    'args'                => $this->get_location_args(),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/locations/(?P<id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_location'),
                    'permission_callback' => array($this, 'get_item_permissions_check'),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array($this, 'update_location'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => $this->get_location_args(),
                ),
                array(
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => array($this, 'delete_location'),
                    'permission_callback' => array($this, 'delete_item_permissions_check'),
                ),
            )
        );

        // Product inventory endpoints
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/products/(?P<product_id>[\d]+)/inventory',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_product_inventory'),
                    'permission_callback' => array($this, 'get_items_permissions_check'),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'create_product_inventory'),
                    'permission_callback' => array($this, 'create_item_permissions_check'),
                    'args'                => $this->get_inventory_args(),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/products/(?P<product_id>[\d]+)/inventory/(?P<inventory_id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_inventory_item'),
                    'permission_callback' => array($this, 'get_item_permissions_check'),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array($this, 'update_inventory_item'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => $this->get_inventory_args(),
                ),
                array(
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => array($this, 'delete_inventory_item'),
                    'permission_callback' => array($this, 'delete_item_permissions_check'),
                ),
            )
        );

        // Stock management endpoints
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/stock/update',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'update_stock'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => $this->get_stock_update_args(),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/stock/bulk-update',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'bulk_update_stock'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => array(
                        'updates' => array(
                            'description' => 'Array of stock updates',
                            'type'        => 'array',
                            'required'    => true,
                        ),
                    ),
                ),
            )
        );

        // Transfer stock between locations
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/stock/transfer',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'transfer_stock'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => $this->get_transfer_args(),
                ),
            )
        );

        // Location stock overview
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/locations/(?P<location_id>[\d]+)/stock',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_location_stock'),
                    'permission_callback' => array($this, 'get_items_permissions_check'),
                ),
            )
        );

        // Low stock alerts
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/stock/low-stock',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_low_stock_items'),
                    'permission_callback' => array($this, 'get_items_permissions_check'),
                ),
            )
        );

        // Stock conversion (e.g., flower to pre-rolls)
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/stock/convert',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'convert_stock'),
                    'permission_callback' => array($this, 'update_item_permissions_check'),
                    'args'                => $this->get_conversion_args(),
                ),
            )
        );

        // Bulk inventory fetch for POS systems
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/inventory/bulk',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array($this, 'get_bulk_inventory'),
                    'permission_callback' => array($this, 'get_items_permissions_check'),
                    'args'                => array(
                        'product_ids' => array(
                            'description' => 'Array of product IDs to fetch inventory for',
                            'type'        => 'array',
                            'required'    => true,
                        ),
                        'location_id' => array(
                            'description' => 'Location ID to filter inventory by',
                            'type'        => 'integer',
                            'required'    => false,
                        ),
                    ),
                ),
            )
        );

        // WooCommerce Tax rates endpoint for a specific location
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/location/(?P<id>[\d]+)/tax-rates',
            array(
                'args'   => array(
                    'id' => array(
                        'description' => esc_html__('Unique identifier for the location.', 'addify-multi-inventory-management'),
                        'type'        => 'integer',
                        'required'    => true,
                    ),
                ),
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_woo_location_tax_rates' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                ),
                'schema' => array( $this, 'get_tax_rates_schema' ),
            )
        );

        // Tax rates endpoint for all locations
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/locations/tax-rates',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_all_woo_locations_tax_rates' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                ),
                'schema' => array( $this, 'get_tax_rates_schema' ),
            )
        );
    }

    /**
     * Get all locations.
     */
    public function get_locations($request) {
        $terms = get_terms(array(
            'taxonomy'   => $this->location_taxonomy,
            'hide_empty' => false,
        ));

        if (is_wp_error($terms)) {
            return new WP_Error('invalid_taxonomy', __('Invalid taxonomy.', 'addify-multi-inventory-management'), array('status' => 400));
        }

        $locations = array();
        foreach ($terms as $term) {
            $locations[] = $this->prepare_location_for_response($term);
        }

        return rest_ensure_response($locations);
    }

    /**
     * Get single location.
     */
    public function get_location($request) {
        $term = get_term($request['id'], $this->location_taxonomy);

        if (is_wp_error($term) || !$term) {
            return new WP_Error('invalid_location', __('Invalid location ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        return rest_ensure_response($this->prepare_location_for_response($term));
    }

    /**
     * Create new location.
     */
    public function create_location($request) {
        $args = array(
            'description' => $request['description'] ?? '',
            'slug'        => $request['slug'] ?? '',
        );

        $term = wp_insert_term($request['name'], $this->location_taxonomy, $args);

        if (is_wp_error($term)) {
            return $term;
        }

        $location = get_term($term['term_id'], $this->location_taxonomy);
        
        // Add location meta data
        if (!empty($request['address'])) {
            update_term_meta($term['term_id'], 'location_address', sanitize_text_field($request['address']));
        }
        if (!empty($request['manager'])) {
            update_term_meta($term['term_id'], 'location_manager', sanitize_text_field($request['manager']));
        }
        if (!empty($request['phone'])) {
            update_term_meta($term['term_id'], 'location_phone', sanitize_text_field($request['phone']));
        }

        return rest_ensure_response($this->prepare_location_for_response($location));
    }

    /**
     * Update location.
     */
    public function update_location($request) {
        $term = get_term($request['id'], $this->location_taxonomy);

        if (is_wp_error($term) || !$term) {
            return new WP_Error('invalid_location', __('Invalid location ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $args = array();
        if (!empty($request['name'])) {
            $args['name'] = $request['name'];
        }
        if (!empty($request['description'])) {
            $args['description'] = $request['description'];
        }
        if (!empty($request['slug'])) {
            $args['slug'] = $request['slug'];
        }

        if (!empty($args)) {
            $result = wp_update_term($request['id'], $this->location_taxonomy, $args);
            if (is_wp_error($result)) {
                return $result;
            }
        }

        // Update meta data
        if (isset($request['address'])) {
            update_term_meta($request['id'], 'location_address', sanitize_text_field($request['address']));
        }
        if (isset($request['manager'])) {
            update_term_meta($request['id'], 'location_manager', sanitize_text_field($request['manager']));
        }
        if (isset($request['phone'])) {
            update_term_meta($request['id'], 'location_phone', sanitize_text_field($request['phone']));
        }

        $updated_term = get_term($request['id'], $this->location_taxonomy);
        return rest_ensure_response($this->prepare_location_for_response($updated_term));
    }

    /**
     * Delete location.
     */
    public function delete_location($request) {
        $term = get_term($request['id'], $this->location_taxonomy);

        if (is_wp_error($term) || !$term) {
            return new WP_Error('invalid_location', __('Invalid location ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $result = wp_delete_term($request['id'], $this->location_taxonomy);

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response(array('deleted' => true, 'previous' => $this->prepare_location_for_response($term)));
    }

    /**
     * Get product inventory across all locations.
     */
    public function get_product_inventory($request) {
        $product_id = $request['product_id'];
        
        $inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'post_parent'    => $product_id,
        ));

        $inventory_data = array();
        foreach ($inventories as $inventory) {
            $inventory_data[] = $this->prepare_inventory_for_response($inventory, $product_id);
        }

        return rest_ensure_response($inventory_data);
    }

    /**
     * Create product inventory for specific location.
     */
    public function create_product_inventory($request) {
        $product_id = $request['product_id'];
        $location_id = $request['location_id'];
        $quantity = $request['quantity'] ?? 0;
        $name = $request['name'] ?? "Inventory for Location {$location_id}";

        // Check if product exists
        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('invalid_product', __('Invalid product ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        // Check if location exists
        $location = get_term($location_id, $this->location_taxonomy);
        if (is_wp_error($location) || !$location) {
            return new WP_Error('invalid_location', __('Invalid location ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        // Debug: Check if post type exists
        if (!post_type_exists($this->inventory_post_type)) {
            return new WP_Error('post_type_not_found', __('Post type af_prod_lvl_invent is not registered.', 'addify-multi-inventory-management'), array('status' => 500));
        }
        
        // Debug: Check current user capabilities
        if (!current_user_can('edit_posts')) {
            return new WP_Error('insufficient_permissions', __('Current user cannot create posts.', 'addify-multi-inventory-management'), array('status' => 403));
        }
        
        // Check if inventory already exists for this product-location combination
        $existing_inventories = get_posts(array(
            'post_type' => $this->inventory_post_type,
            'post_parent' => $product_id,
            'post_status' => 'publish',
            'numberposts' => -1,
            'meta_query' => array(
                array(
                    'key' => 'in_location',
                    'value' => $location_id,
                    'compare' => '='
                )
            )
        ));
        
        // If inventory exists, update it instead of creating a new one
        if (!empty($existing_inventories)) {
            $inventory_id = $existing_inventories[0]->ID;
            
            // Update existing inventory quantity
            $current_quantity = get_post_meta($inventory_id, 'in_stock_quantity', true) ?: 0;
            update_post_meta($inventory_id, 'in_stock_quantity', $quantity);
            
            // Update the title if a custom name was provided
            if ($request['name']) {
                wp_update_post(array(
                    'ID' => $inventory_id,
                    'post_title' => $name
                ));
                update_post_meta($inventory_id, 'af_inventory_name', $name);
            }
            
            // Update product meta to reflect inventory changes
            $this->update_product_inventory_meta($product_id);
            
            $inventory = get_post($inventory_id);
            $response_data = $this->prepare_inventory_for_response($inventory, $product_id);
            $response_data['updated'] = true; // Flag to indicate this was an update
            $response_data['previous_quantity'] = $current_quantity;
            
            return rest_ensure_response($response_data);
        }
        
        // Create new inventory if none exists
        $post_data = array(
            'post_type'   => $this->inventory_post_type,
            'post_status' => 'publish',
            'post_parent' => $product_id,
            'post_title'  => $name,
            'post_author' => get_current_user_id() ?: 1, // Use admin user if no current user
        );
        
        $inventory_id = wp_insert_post($post_data, true);

        if (is_wp_error($inventory_id)) {
            return new WP_Error('wp_insert_post_failed', $inventory_id->get_error_message(), array('status' => 500, 'wp_error' => $inventory_id->get_error_data()));
        }
        
        if (!$inventory_id || $inventory_id === 0) {
            return new WP_Error('inventory_creation_failed', __('Failed to create inventory post. wp_insert_post returned: ' . var_export($inventory_id, true), 'addify-multi-inventory-management'), array('status' => 500));
        }

        // Set ALL required inventory meta fields
        update_post_meta($inventory_id, 'in_stock_quantity', $quantity);
        update_post_meta($inventory_id, 'in_location', $location_id);
        update_post_meta($inventory_id, 'af_inventory_product_id', $product_id);
        update_post_meta($inventory_id, 'af_inventory_location', $location_id);
        update_post_meta($inventory_id, 'af_inventory_name', $name);
        update_post_meta($inventory_id, 'in_priority', 1);
        update_post_meta($inventory_id, 'in_sku', '');
        update_post_meta($inventory_id, 'in_date', current_time('m/d/Y'));
        update_post_meta($inventory_id, 'in_exp_date', '');
        update_post_meta($inventory_id, 'in_price', 0);
        update_post_meta($inventory_id, 'in_sale_price', '');
        update_post_meta($inventory_id, 'in_low_stock_threshold', '');
        
        // Set location taxonomy
        wp_set_post_terms($inventory_id, array($location_id), $this->location_taxonomy);

        // Update product meta to reflect new inventory
        $this->update_product_inventory_meta($product_id);

        $inventory = get_post($inventory_id);
        if (!$inventory) {
            return new WP_Error('inventory_not_created', __('Failed to retrieve created inventory post. Post ID: ' . $inventory_id, 'addify-multi-inventory-management'), array('status' => 500));
        }
        
        $response_data = $this->prepare_inventory_for_response($inventory, $product_id);
        if (empty($response_data)) {
            return new WP_Error('invalid_response', __('Failed to prepare inventory response.', 'addify-multi-inventory-management'), array('status' => 500));
        }
        
        return rest_ensure_response($response_data);
    }

    /**
     * Update product meta fields after inventory changes
     */
    private function update_product_inventory_meta($product_id) {
        // Get all inventories for this product
        $inventories = get_posts(array(
            'post_type' => $this->inventory_post_type,
            'post_parent' => $product_id,
            'post_status' => 'publish',
            'numberposts' => -1
        ));

        $total_stock = 0;
        $location_names = array();
        $location_ids = array();
        $inventory_count = count($inventories);

        foreach ($inventories as $inventory) {
            $stock = get_post_meta($inventory->ID, 'in_stock_quantity', true);
            $total_stock += floatval($stock);
            
            $location_id = get_post_meta($inventory->ID, 'in_location', true);
            if ($location_id) {
                $location_ids[] = $location_id;
                $location = get_term($location_id, $this->location_taxonomy);
                if ($location && !is_wp_error($location)) {
                    $location_names[] = $location->name;
                    // Set location-specific meta
                    update_post_meta($product_id, "af_mli_has_" . strtolower(str_replace(' ', '_', $location->name)) . "_inventory", "yes");
                    update_post_meta($product_id, "_af_mli_has_" . strtolower(str_replace(' ', '_', $location->name)) . "_inventory", "yes");
                }
            }
        }

        // Update product stock
        update_post_meta($product_id, '_stock', $total_stock);
        update_post_meta($product_id, 'in_stock_quantity', $total_stock);
        update_post_meta($product_id, '_stock_status', $total_stock > 0 ? 'instock' : 'outofstock');
        
        // Update Addify meta fields
        update_post_meta($product_id, 'af_mli_has_multi_inventory', 'yes');
        update_post_meta($product_id, '_af_mli_has_multi_inventory', 'yes');
        update_post_meta($product_id, 'af_mli_inventory_count', $inventory_count);
        update_post_meta($product_id, 'af_mli_inventory_list', implode(', ', array_unique($location_names)));
        update_post_meta($product_id, 'af_mli_inventory_names', implode(', ', array_unique($location_names)));
        
        // Enable multi-inventory for the product
        update_post_meta($product_id, '_use_multi_inventory', 'yes');
        update_post_meta($product_id, 'use_multi_inventory', 'yes');
        update_post_meta($product_id, '_multi_inventory_enabled', 'yes');
        update_post_meta($product_id, 'multi_inventory_enabled', 'yes');
        update_post_meta($product_id, 'prod_level_inven', 'yes');

        // CRITICAL: Attach location taxonomy terms to the product
        if (!empty($location_ids)) {
            wp_set_post_terms($product_id, array_unique($location_ids), $this->location_taxonomy);
        }

        // Update WooCommerce product object
        $product = wc_get_product($product_id);
        if ($product) {
            $product->set_stock_quantity($total_stock);
            $product->set_stock_status($total_stock > 0 ? 'instock' : 'outofstock');
            $product->set_manage_stock(true);
            $product->save();
        }
    }

    /**
     * Get specific inventory item.
     */
    public function get_inventory_item($request) {
        $inventory = get_post($request['inventory_id']);

        if (!$inventory || $inventory->post_type !== $this->inventory_post_type) {
            return new WP_Error('invalid_inventory', __('Invalid inventory ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        return rest_ensure_response($this->prepare_inventory_for_response($inventory, $request['product_id']));
    }

    /**
     * Update inventory item.
     */
    public function update_inventory_item($request) {
        $inventory = get_post($request['inventory_id']);

        if (!$inventory || $inventory->post_type !== $this->inventory_post_type) {
            return new WP_Error('invalid_inventory', __('Invalid inventory ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        // Update quantity if provided
        if (isset($request['quantity'])) {
            update_post_meta($request['inventory_id'], 'in_stock_quantity', intval($request['quantity']));
        }

        // Update location if provided
        if (isset($request['location_id'])) {
            $location = get_term($request['location_id'], $this->location_taxonomy);
            if (!is_wp_error($location) && $location) {
                update_post_meta($request['inventory_id'], 'in_location', $request['location_id']);
                update_post_meta($request['inventory_id'], 'af_inventory_location', $request['location_id']);
                wp_set_post_terms($request['inventory_id'], array($request['location_id']), $this->location_taxonomy);
            }
        }

        // Update name if provided
        if (isset($request['name'])) {
            wp_update_post(array(
                'ID'         => $request['inventory_id'],
                'post_title' => $request['name'],
            ));
            update_post_meta($request['inventory_id'], 'af_inventory_name', $request['name']);
        }

        // Update product meta to reflect inventory changes
        $this->update_product_inventory_meta($request['product_id']);

        $updated_inventory = get_post($request['inventory_id']);
        return rest_ensure_response($this->prepare_inventory_for_response($updated_inventory, $request['product_id']));
    }

    /**
     * Delete inventory item.
     */
    public function delete_inventory_item($request) {
        $inventory = get_post($request['inventory_id']);

        if (!$inventory || $inventory->post_type !== $this->inventory_post_type) {
            return new WP_Error('invalid_inventory', __('Invalid inventory ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $result = wp_delete_post($request['inventory_id'], true);

        if (!$result) {
            return new WP_Error('cant_delete', __('Could not delete inventory item.', 'addify-multi-inventory-management'), array('status' => 500));
        }

        // Update product meta to reflect inventory changes
        $this->update_product_inventory_meta($request['product_id']);

        return rest_ensure_response(array('deleted' => true, 'previous' => $this->prepare_inventory_for_response($inventory, $request['product_id'])));
    }

    /**
     * Update stock quantity for specific inventory.
     */
    public function update_stock($request) {
        $inventory_id = $request['inventory_id'];
        $quantity = $request['quantity'];
        $operation = $request['operation'] ?? 'set'; // set, add, subtract

        $inventory = get_post($inventory_id);
        if (!$inventory || $inventory->post_type !== $this->inventory_post_type) {
            return new WP_Error('invalid_inventory', __('Invalid inventory ID.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $current_quantity = get_post_meta($inventory_id, 'in_stock_quantity', true) ?: 0;

        switch ($operation) {
            case 'add':
                $new_quantity = $current_quantity + $quantity;
                break;
            case 'subtract':
                $new_quantity = max(0, $current_quantity - $quantity);
                break;
            default:
                $new_quantity = $quantity;
                break;
        }

        update_post_meta($inventory_id, 'in_stock_quantity', $new_quantity);

        // Update product meta to reflect stock changes
        $product_id = $inventory->post_parent;
        if ($product_id) {
            $this->update_product_inventory_meta($product_id);
        }

        return rest_ensure_response(array(
            'inventory_id'     => $inventory_id,
            'previous_quantity' => $current_quantity,
            'new_quantity'     => $new_quantity,
            'operation'        => $operation,
        ));
    }

    /**
     * Bulk update stock quantities.
     */
    public function bulk_update_stock($request) {
        $updates = $request['updates'];
        $results = array();
        $affected_products = array();

        foreach ($updates as $update) {
            if (!isset($update['inventory_id']) || !isset($update['quantity'])) {
                continue;
            }

            $inventory_id = $update['inventory_id'];
            $quantity = $update['quantity'];
            $operation = $update['operation'] ?? 'set';

            $inventory = get_post($inventory_id);
            if (!$inventory || $inventory->post_type !== $this->inventory_post_type) {
                $results[] = array(
                    'inventory_id' => $inventory_id,
                    'error'        => 'Invalid inventory ID',
                );
                continue;
            }

            $current_quantity = get_post_meta($inventory_id, 'in_stock_quantity', true) ?: 0;

            switch ($operation) {
                case 'add':
                    $new_quantity = $current_quantity + $quantity;
                    break;
                case 'subtract':
                    $new_quantity = max(0, $current_quantity - $quantity);
                    break;
                default:
                    $new_quantity = $quantity;
                    break;
            }

            update_post_meta($inventory_id, 'in_stock_quantity', $new_quantity);

            // Track affected products
            $product_id = $inventory->post_parent;
            if ($product_id) {
                $affected_products[] = $product_id;
            }

            $results[] = array(
                'inventory_id'      => $inventory_id,
                'previous_quantity' => $current_quantity,
                'new_quantity'      => $new_quantity,
                'operation'         => $operation,
            );
        }

        // Update product meta for all affected products
        foreach (array_unique($affected_products) as $product_id) {
            $this->update_product_inventory_meta($product_id);
        }

        return rest_ensure_response($results);
    }

    /**
     * Get bulk inventory data for multiple products.
     */
    public function get_bulk_inventory($request) {
        $product_ids = $request['product_ids'];
        $location_id = $request['location_id'] ?? null;
        
        if (empty($product_ids) || !is_array($product_ids)) {
            return new WP_Error('invalid_products', __('Product IDs array is required.', 'addify-multi-inventory-management'), array('status' => 400));
        }

        $bulk_inventory = array();

        foreach ($product_ids as $product_id) {
            $product_id = intval($product_id);
            
            // Get all inventory for this product
            $inventories = get_posts(array(
                'post_type'      => $this->inventory_post_type,
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'post_parent'    => $product_id,
            ));

            $product_inventory = array();
            
            foreach ($inventories as $inventory) {
                $inventory_data = $this->prepare_inventory_for_response($inventory, $product_id);
                
                // If location filter is specified, only include matching locations
                if ($location_id && $inventory_data['location_id'] != $location_id) {
                    continue;
                }
                
                // Only include items with stock > 0
                if ($inventory_data['quantity'] > 0) {
                    $product_inventory[] = $inventory_data;
                }
            }

            if (!empty($product_inventory)) {
                $bulk_inventory[$product_id] = $product_inventory;
            }
        }

        return rest_ensure_response($bulk_inventory);
    }

    /**
     * Transfer stock between locations.
     */
    public function transfer_stock($request) {
        $product_id = $request['product_id'];
        $from_location = $request['from_location_id'];
        $to_location = $request['to_location_id'];
        $quantity = $request['quantity'];

        // Get source inventory
        $from_inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'post_parent'    => $product_id,
            'meta_query'     => array(
                array(
                    'key'   => 'mli_location',
                    'value' => $from_location,
                ),
            ),
        ));

        if (empty($from_inventories)) {
            return new WP_Error('no_source_inventory', __('No inventory found at source location.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $from_inventory = $from_inventories[0];
        $from_quantity = get_post_meta($from_inventory->ID, 'in_stock_quantity', true) ?: 0;

        if ($from_quantity < $quantity) {
            return new WP_Error('insufficient_stock', __('Insufficient stock at source location.', 'addify-multi-inventory-management'), array('status' => 400));
        }

        // Get or create destination inventory
        $to_inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'post_parent'    => $product_id,
            'meta_query'     => array(
                array(
                    'key'   => 'mli_location',
                    'value' => $to_location,
                ),
            ),
        ));

        if (empty($to_inventories)) {
            // Create new inventory at destination
            $to_inventory_id = wp_insert_post(array(
                'post_type'   => $this->inventory_post_type,
                'post_status' => 'publish',
                'post_parent' => $product_id,
                'post_title'  => "Inventory for Location {$to_location}",
            ));

            update_post_meta($to_inventory_id, 'in_stock_quantity', 0);
            update_post_meta($to_inventory_id, 'mli_location', $to_location);
            wp_set_post_terms($to_inventory_id, array($to_location), $this->location_taxonomy);
            
            $to_inventory = get_post($to_inventory_id);
            $to_quantity = 0;
        } else {
            $to_inventory = $to_inventories[0];
            $to_quantity = get_post_meta($to_inventory->ID, 'in_stock_quantity', true) ?: 0;
        }

        // Perform transfer
        update_post_meta($from_inventory->ID, 'in_stock_quantity', $from_quantity - $quantity);
        update_post_meta($to_inventory->ID, 'in_stock_quantity', $to_quantity + $quantity);

        return rest_ensure_response(array(
            'product_id'    => $product_id,
            'from_location' => $from_location,
            'to_location'   => $to_location,
            'quantity'      => $quantity,
            'from_remaining' => $from_quantity - $quantity,
            'to_new_total'  => $to_quantity + $quantity,
        ));
    }

    /**
     * Convert stock from one product to another (e.g., flower to pre-rolls).
     */
    public function convert_stock($request) {
        $from_product_id = $request['from_product_id'];
        $to_product_id = $request['to_product_id'];
        $from_quantity = $request['from_quantity'];
        $to_quantity = $request['to_quantity'];
        $location_id = $request['location_id'];
        $notes = $request['notes'] ?? '';

        // Validate products exist
        $from_product = wc_get_product($from_product_id);
        $to_product = wc_get_product($to_product_id);

        if (!$from_product || !$to_product) {
            return new WP_Error('invalid_products', __('Invalid product IDs.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        // Get source inventory
        $from_inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'post_parent'    => $from_product_id,
            'meta_query'     => array(
                array(
                    'key'   => 'mli_location',
                    'value' => $location_id,
                ),
            ),
        ));

        if (empty($from_inventories)) {
            return new WP_Error('no_source_inventory', __('No inventory found for source product at this location.', 'addify-multi-inventory-management'), array('status' => 404));
        }

        $from_inventory = $from_inventories[0];
        $from_current_quantity = get_post_meta($from_inventory->ID, 'in_stock_quantity', true) ?: 0;

        if ($from_current_quantity < $from_quantity) {
            return new WP_Error('insufficient_stock', __('Insufficient stock for conversion.', 'addify-multi-inventory-management'), array('status' => 400));
        }

        // Get or create target inventory
        $to_inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'post_parent'    => $to_product_id,
            'meta_query'     => array(
                array(
                    'key'   => 'mli_location',
                    'value' => $location_id,
                ),
            ),
        ));

        if (empty($to_inventories)) {
            // Create new inventory for target product
            $to_inventory_id = wp_insert_post(array(
                'post_type'   => $this->inventory_post_type,
                'post_status' => 'publish',
                'post_parent' => $to_product_id,
                'post_title'  => "Inventory for Location {$location_id}",
            ));

            update_post_meta($to_inventory_id, 'in_stock_quantity', 0);
            update_post_meta($to_inventory_id, 'mli_location', $location_id);
            wp_set_post_terms($to_inventory_id, array($location_id), $this->location_taxonomy);
            
            $to_inventory = get_post($to_inventory_id);
            $to_current_quantity = 0;
        } else {
            $to_inventory = $to_inventories[0];
            $to_current_quantity = get_post_meta($to_inventory->ID, 'in_stock_quantity', true) ?: 0;
        }

        // Perform conversion
        update_post_meta($from_inventory->ID, 'in_stock_quantity', $from_current_quantity - $from_quantity);
        update_post_meta($to_inventory->ID, 'in_stock_quantity', $to_current_quantity + $to_quantity);

        // Log the conversion (optional - for tracking)
        $conversion_log = array(
            'from_product' => $from_product_id,
            'to_product' => $to_product_id,
            'from_quantity' => $from_quantity,
            'to_quantity' => $to_quantity,
            'location' => $location_id,
            'timestamp' => current_time('mysql'),
            'notes' => $notes,
        );
        
        // Store conversion log as post meta on both inventories
        add_post_meta($from_inventory->ID, 'conversion_log', $conversion_log);
        add_post_meta($to_inventory->ID, 'conversion_log', $conversion_log);

        return rest_ensure_response(array(
            'from_product_id' => $from_product_id,
            'from_product_name' => $from_product->get_name(),
            'to_product_id' => $to_product_id,
            'to_product_name' => $to_product->get_name(),
            'from_quantity' => $from_quantity,
            'to_quantity' => $to_quantity,
            'location_id' => $location_id,
            'from_remaining' => $from_current_quantity - $from_quantity,
            'to_new_total' => $to_current_quantity + $to_quantity,
            'conversion_ratio' => $to_quantity / $from_quantity,
            'notes' => $notes,
        ));
    }

    /**
     * Get all stock items for a specific location.
     */
    public function get_location_stock($request) {
        $location_id = $request['location_id'];

        $inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'   => 'in_location',
                    'value' => $location_id,
                ),
            ),
        ));

        $stock_data = array();
        foreach ($inventories as $inventory) {
            $product_id = $inventory->post_parent;
            $product = wc_get_product($product_id);
            
            if ($product) {
                $stock_data[] = array(
                    'inventory_id' => $inventory->ID,
                    'product_id'   => $product_id,
                    'product_name' => $product->get_name(),
                    'product_sku'  => $product->get_sku(),
                    'quantity'     => get_post_meta($inventory->ID, 'in_stock_quantity', true) ?: 0,
                );
            }
        }

        return rest_ensure_response($stock_data);
    }

    /**
     * Get low stock items across all locations.
     */
    public function get_low_stock_items($request) {
        $threshold = $request['threshold'] ?? 10;

        $inventories = get_posts(array(
            'post_type'      => $this->inventory_post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'     => 'in_stock_quantity',
                    'value'   => $threshold,
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                ),
            ),
        ));

        $low_stock_items = array();
        foreach ($inventories as $inventory) {
            $product_id = $inventory->post_parent;
            $product = wc_get_product($product_id);
            $location_id = get_post_meta($inventory->ID, 'in_location', true);
            $location = get_term($location_id, $this->location_taxonomy);

            if ($product && $location) {
                $low_stock_items[] = array(
                    'inventory_id'  => $inventory->ID,
                    'product_id'    => $product_id,
                    'product_name'  => $product->get_name(),
                    'product_sku'   => $product->get_sku(),
                    'location_id'   => $location_id,
                    'location_name' => $location->name,
                    'quantity'      => get_post_meta($inventory->ID, 'in_stock_quantity', true) ?: 0,
                );
            }
        }

        return rest_ensure_response($low_stock_items);
    }

    /**
     * Prepare location for API response.
     */
    private function prepare_location_for_response($term) {
        return array(
            'id'          => $term->term_id,
            'name'        => $term->name,
            'slug'        => $term->slug,
            'description' => $term->description,
            'address'     => get_term_meta($term->term_id, 'location_address', true),
            'manager'     => get_term_meta($term->term_id, 'location_manager', true),
            'phone'       => get_term_meta($term->term_id, 'location_phone', true),
        );
    }

    /**
     * Prepare inventory for API response.
     */
    private function prepare_inventory_for_response($inventory, $product_id) {
        $location_id = get_post_meta($inventory->ID, 'in_location', true);
        $location = get_term($location_id, $this->location_taxonomy);

        return array(
            'id'            => $inventory->ID,
            'name'          => $inventory->post_title,
            'product_id'    => $product_id,
            'location_id'   => $location_id,
            'location_name' => $location ? $location->name : '',
            'quantity'      => get_post_meta($inventory->ID, 'in_stock_quantity', true) ?: 0,
            'created_date'  => $inventory->post_date,
        );
    }

    /**
     * Get location arguments for validation.
     */
    private function get_location_args() {
        return array(
            'name' => array(
                'description' => 'Location name',
                'type'        => 'string',
                'required'    => true,
            ),
            'description' => array(
                'description' => 'Location description',
                'type'        => 'string',
            ),
            'slug' => array(
                'description' => 'Location slug',
                'type'        => 'string',
            ),
            'address' => array(
                'description' => 'Location address',
                'type'        => 'string',
            ),
            'manager' => array(
                'description' => 'Location manager',
                'type'        => 'string',
            ),
            'phone' => array(
                'description' => 'Location phone',
                'type'        => 'string',
            ),
        );
    }

    /**
     * Get inventory arguments for validation.
     */
    private function get_inventory_args() {
        return array(
            'location_id' => array(
                'description' => 'Location ID',
                'type'        => 'integer',
                'required'    => true,
            ),
            'quantity' => array(
                'description' => 'Stock quantity (supports decimals for weight-based products)',
                'type'        => 'number',
                'default'     => 0,
            ),
            'name' => array(
                'description' => 'Inventory name',
                'type'        => 'string',
            ),
        );
    }

    /**
     * Get stock update arguments for validation.
     */
    private function get_stock_update_args() {
        return array(
            'inventory_id' => array(
                'description' => 'Inventory ID',
                'type'        => 'integer',
                'required'    => true,
            ),
            'quantity' => array(
                'description' => 'Quantity to update (supports decimals for weight-based products)',
                'type'        => 'number',
                'required'    => true,
            ),
            'operation' => array(
                'description' => 'Operation type',
                'type'        => 'string',
                'enum'        => array('set', 'add', 'subtract'),
                'default'     => 'set',
            ),
        );
    }

    /**
     * Get transfer arguments for validation.
     */
    private function get_transfer_args() {
        return array(
            'product_id' => array(
                'description' => 'Product ID',
                'type'        => 'integer',
                'required'    => true,
            ),
            'from_location_id' => array(
                'description' => 'Source location ID',
                'type'        => 'integer',
                'required'    => true,
            ),
            'to_location_id' => array(
                'description' => 'Destination location ID',
                'type'        => 'integer',
                'required'    => true,
            ),
            'quantity' => array(
                'description' => 'Quantity to transfer (supports decimals for weight-based products)',
                'type'        => 'number',
                'required'    => true,
            ),
        );
    }

    /**
     * Get conversion arguments for validation.
     */
    private function get_conversion_args() {
        return array(
            'from_product_id' => array(
                'description' => 'Source product ID (e.g., flower)',
                'type'        => 'integer',
                'required'    => true,
            ),
            'to_product_id' => array(
                'description' => 'Target product ID (e.g., pre-rolls)',
                'type'        => 'integer',
                'required'    => true,
            ),
            'from_quantity' => array(
                'description' => 'Quantity to convert from source (supports decimals)',
                'type'        => 'number',
                'required'    => true,
            ),
            'to_quantity' => array(
                'description' => 'Quantity to add to target (supports decimals)',
                'type'        => 'number',
                'required'    => true,
            ),
            'location_id' => array(
                'description' => 'Location ID where conversion happens',
                'type'        => 'integer',
                'required'    => true,
            ),
            'notes' => array(
                'description' => 'Optional notes about the conversion',
                'type'        => 'string',
                'required'    => false,
            ),
        );
    }

    /**
     * Check permissions for reading items.
     */
    public function get_items_permissions_check($request) {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Check permissions for reading single item.
     */
    public function get_item_permissions_check($request) {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Check permissions for creating items.
     */
    public function create_item_permissions_check($request) {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Check permissions for updating items.
     */
    public function update_item_permissions_check($request) {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Check permissions for deleting items.
     */
    public function delete_item_permissions_check($request) {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Get WooCommerce tax rates for a specific location.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function get_woo_location_tax_rates( $request ) {
        $location_id = absint( $request['id'] );
        
        // Check if location exists
        $location = get_term( $location_id, $this->location_taxonomy );
        if ( ! $location || is_wp_error( $location ) ) {
            return new WP_Error( 
                'rest_location_invalid', 
                __( 'Invalid location ID.', 'addify-multi-inventory-management' ), 
                array( 'status' => 404 ) 
            );
        }
        
        // Get WooCommerce tax rates for this location
        if ( class_exists( 'Addify_MLI_Woo_Tax_Integration' ) ) {
            $tax_data = Addify_MLI_Woo_Tax_Integration::get_location_tax_rates( $location_id );
        } else {
            $tax_data = array(
                'tax_rates' => array(),
                'total_rate' => 0
            );
        }
        
        // Prepare response data
        $data = array(
            'location_id'   => $location_id,
            'location_name' => $location->name,
            'tax_rates'     => $tax_data['tax_rates'],
            'total_rate'    => $tax_data['total_rate'],
        );
        
        return rest_ensure_response( $data );
    }
    
    /**
     * Get WooCommerce tax rates for all locations.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error
     */
    public function get_all_woo_locations_tax_rates( $request ) {
        // Get all locations
        $locations = get_terms( array(
            'taxonomy'   => $this->location_taxonomy,
            'hide_empty' => false,
        ) );
        
        if ( is_wp_error( $locations ) ) {
            return $locations;
        }
        
        $data = array();
        
        foreach ( $locations as $location ) {
            if ( class_exists( 'Addify_MLI_Woo_Tax_Integration' ) ) {
                $tax_data = Addify_MLI_Woo_Tax_Integration::get_location_tax_rates( $location->term_id );
            } else {
                $tax_data = array(
                    'tax_rates' => array(),
                    'total_rate' => 0
                );
            }
            
            $data[] = array(
                'location_id'   => $location->term_id,
                'location_name' => $location->name,
                'tax_rates'     => $tax_data['tax_rates'],
                'total_rate'    => $tax_data['total_rate'],
            );
        }
        
        return rest_ensure_response( $data );
    }
    
    /**
     * Calculate total tax rate from array of tax rates.
     *
     * @param array $tax_rates Array of tax rates.
     * @return float Total tax rate.
     */
    private function calculate_total_tax_rate( $tax_rates ) {
        $total_rate = 0;
        $compound_rates = array();
        
        // First, apply non-compound rates
        foreach ( $tax_rates as $rate ) {
            if ( empty( $rate['rate'] ) ) {
                continue;
            }
            
            if ( $rate['compound'] !== 'yes' && $rate['type'] === 'percentage' ) {
                $total_rate += floatval( $rate['rate'] );
            } elseif ( $rate['compound'] === 'yes' && $rate['type'] === 'percentage' ) {
                $compound_rates[] = floatval( $rate['rate'] );
            }
        }
        
        // Then apply compound rates
        $compound_total = $total_rate;
        foreach ( $compound_rates as $compound_rate ) {
            $compound_total += ( ( 100 + $compound_total ) * $compound_rate / 100 );
        }
        
        return $compound_total > 0 ? $compound_total : $total_rate;
    }
    
    /**
     * Get tax rates schema.
     *
     * @return array
     */
    public function get_tax_rates_schema() {
        return array(
            '$schema'    => 'http://json-schema.org/draft-04/schema#',
            'title'      => 'tax_rates',
            'type'       => 'object',
            'properties' => array(
                'location_id'   => array(
                    'description' => __( 'The location ID.', 'addify-multi-inventory-management' ),
                    'type'        => 'integer',
                    'context'     => array( 'view' ),
                    'readonly'    => true,
                ),
                'location_name' => array(
                    'description' => __( 'The location name.', 'addify-multi-inventory-management' ),
                    'type'        => 'string',
                    'context'     => array( 'view' ),
                    'readonly'    => true,
                ),
                'tax_rates'     => array(
                    'description' => __( 'Array of tax rates for the location.', 'addify-multi-inventory-management' ),
                    'type'        => 'array',
                    'context'     => array( 'view' ),
                    'items'       => array(
                        'type'       => 'object',
                        'properties' => array(
                            'id'       => array(
                                'description' => __( 'WooCommerce tax rate ID.', 'addify-multi-inventory-management' ),
                                'type'        => 'integer',
                            ),
                            'name'     => array(
                                'description' => __( 'Tax name.', 'addify-multi-inventory-management' ),
                                'type'        => 'string',
                            ),
                            'rate'     => array(
                                'description' => __( 'Tax rate (percentage).', 'addify-multi-inventory-management' ),
                                'type'        => 'number',
                            ),
                            'compound' => array(
                                'description' => __( 'Whether this is a compound tax.', 'addify-multi-inventory-management' ),
                                'type'        => 'string',
                                'enum'        => array( 'yes', 'no' ),
                            ),
                            'shipping' => array(
                                'description' => __( 'Whether tax applies to shipping.', 'addify-multi-inventory-management' ),
                                'type'        => 'string',
                                'enum'        => array( 'yes', 'no' ),
                            ),
                            'class'    => array(
                                'description' => __( 'Tax class.', 'addify-multi-inventory-management' ),
                                'type'        => 'string',
                            ),
                        ),
                    ),
                ),
                'total_rate'    => array(
                    'description' => __( 'Total calculated tax rate.', 'addify-multi-inventory-management' ),
                    'type'        => 'number',
                    'context'     => array( 'view' ),
                    'readonly'    => true,
                ),
            ),
        );
    }
} 